from __future__ import annotations

import argparse
import copy
import json
import math
import os
import traceback
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
import requests
import timesfm
from requests import Session
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from cycle_shared import (
    CALENDAR,
    DATA_DIR,
    DEFAULT_HTTP_HEADERS,
    SHANGHAI_TZ,
    ensure_config,
    history_source_order,
    load_history,
    normalize_history_source,
    normalize_ticker,
    read_json,
    write_json,
)


def env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


def env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


MARKET_LIST_URLS = [
    "https://push2delay.eastmoney.com/api/qt/clist/get",
    "http://82.push2.eastmoney.com/api/qt/clist/get",
    "http://20.push2.eastmoney.com/api/qt/clist/get",
    "https://20.push2.eastmoney.com/api/qt/clist/get",
    "https://push2.eastmoney.com/api/qt/clist/get",
]
MARKET_SCAN_PATH = DATA_DIR / "market_scan_25.json"
MARKET_SCAN_HISTORY_PATH = DATA_DIR / "market_scan_history_25.json"
MARKET_SCAN_STATUS_PATH = DATA_DIR / "market_scan_status.json"
MARKET_UNIVERSE_CACHE_PATH = DATA_DIR / "market_universe_cache.json"
MARKET_SCAN_VERSION = "2.5-market-scan"
MARKET_SCAN_HISTORY_LIMIT = 20
HIT_ERROR_THRESHOLD_PCT = 0.3
UNIVERSE_CACHE_MAX_AGE_SECONDS = 24 * 60 * 60
UNIVERSE_LIST_PAGE_SIZE = 100
UNIVERSE_FETCH_TIMEOUT_SECONDS = 12.0
UNIVERSE_FETCH_RETRIES = max(1, env_int("TIMESFM_UNIVERSE_FETCH_RETRIES", 3))
UNIVERSE_FETCH_WORKERS = max(1, env_int("TIMESFM_UNIVERSE_FETCH_WORKERS", 4))
UNIVERSE_PROGRESS_START = 2.0
UNIVERSE_PROGRESS_END = 6.0
MIN_UNIVERSE_SUCCESS_RATIO = 0.9
DEFAULT_FETCH_WORKERS = max(1, env_int("TIMESFM_MARKET_SCAN_FETCH_WORKERS", 6))
DEFAULT_BATCH_SIZE = max(1, env_int("TIMESFM_MARKET_SCAN_BATCH_SIZE", 48))
DEFAULT_CONTEXT_TARGET = 512
DEFAULT_HISTORY_TIMEOUT_SECONDS = max(3.0, env_float("TIMESFM_MARKET_SCAN_HISTORY_TIMEOUT", 5.0))
DEFAULT_HISTORY_RETRIES = max(1, env_int("TIMESFM_MARKET_SCAN_HISTORY_RETRIES", 1))
STATUS_UPDATE_EVERY = max(5, env_int("TIMESFM_MARKET_SCAN_STATUS_EVERY", 10))
BSE_MARKET_FILTER = "m:0+t:81+s:2048"

BASE_MODEL: timesfm.TimesFM_2p5_200M_torch | None = None
CURRENT_COMPILE_KEY: tuple[int, int, bool] | None = None
MARKET_LIST_SESSION: Session | None = None


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(parsed):
        return default
    return parsed


def is_beijing_code(code: Any) -> bool:
    normalized_code = str(code or "").strip()
    return normalized_code.startswith(("4", "8")) or normalized_code.startswith("92")


def market_code_to_ticker(code: Any, market_code: Any) -> str:
    normalized_code = str(code or "").strip()
    normalized_market = str(market_code or "").strip()
    if not normalized_code:
        return ""
    if is_beijing_code(normalized_code):
        return f"{normalized_code}.BJ"
    return f"{normalized_code}.SS" if normalized_market == "1" else f"{normalized_code}.SZ"


def dedupe_items(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: set[str] = set()
    output: list[dict[str, Any]] = []
    for item in items:
        ticker = str(item.get("ticker", "")).strip()
        if not ticker or ticker in seen:
            continue
        seen.add(ticker)
        output.append(item)
    return output


def market_list_params(page: int, page_size: int) -> dict[str, Any]:
    return {
        "pn": page,
        "pz": page_size,
        "po": 1,
        "np": 1,
        "ut": "bd1d9ddb04089700cf9c27f6f7426281",
        "fltt": 2,
        "invt": 2,
        "fid": "f3",
        "fs": ",".join(["m:0+t:6", "m:0+t:80", "m:1+t:2", "m:1+t:23", BSE_MARKET_FILTER]),
        "fields": "f12,f14,f13,f3,f2,f20,f21,f100",
    }


def normalize_universe_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "ticker": market_code_to_ticker(item.get("f12"), item.get("f13")),
            "code": str(item.get("f12", "")).strip(),
            "name": str(item.get("f14", "")).strip() or str(item.get("f12", "")).strip(),
            "sector": str(item.get("f100", "")).strip() or "未分类",
            "market_cap": safe_float(item.get("f20"), 0.0),
            "float_market_cap": safe_float(item.get("f21"), 0.0),
            "current_price": safe_float(item.get("f2"), 0.0),
            "current_change_pct": safe_float(item.get("f3"), 0.0),
        }
        for item in rows
    ]


def get_cached_universe(limit: int | None = None, allow_stale: bool = False) -> list[dict[str, Any]]:
    cached = read_json(MARKET_UNIVERSE_CACHE_PATH, {})
    generated_at_ts = safe_float(cached.get("generated_at_ts"), 0.0)
    cached_items = cached.get("items", [])
    if not isinstance(cached_items, list) or not cached_items:
        return []
    if not allow_stale:
        min_generated_at = datetime.now(SHANGHAI_TZ).timestamp() - UNIVERSE_CACHE_MAX_AGE_SECONDS
        if generated_at_ts < min_generated_at:
            return []
    items = dedupe_items(cached_items)
    return items[:limit] if limit else items


def get_market_list_session() -> Session:
    global MARKET_LIST_SESSION
    if MARKET_LIST_SESSION is None:
        session = requests.Session()
        retry = Retry(
            total=UNIVERSE_FETCH_RETRIES,
            connect=UNIVERSE_FETCH_RETRIES,
            read=UNIVERSE_FETCH_RETRIES,
            backoff_factor=1.0,
            status_forcelist=[408, 425, 429, 500, 502, 503, 504],
            allowed_methods=frozenset(["GET"]),
            raise_on_status=False,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=UNIVERSE_FETCH_WORKERS, pool_maxsize=UNIVERSE_FETCH_WORKERS * 2)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        MARKET_LIST_SESSION = session
    return MARKET_LIST_SESSION


def fetch_market_list_payload(page: int, page_size: int) -> dict[str, Any]:
    errors: list[str] = []
    start_index = page % len(MARKET_LIST_URLS)
    params = market_list_params(page, page_size)
    session = get_market_list_session()
    for offset in range(len(MARKET_LIST_URLS)):
        url = MARKET_LIST_URLS[(start_index + offset) % len(MARKET_LIST_URLS)]
        try:
            response = session.get(
                url,
                params=params,
                timeout=UNIVERSE_FETCH_TIMEOUT_SECONDS,
                headers=DEFAULT_HTTP_HEADERS,
                allow_redirects=True,
            )
            response.raise_for_status()
            return response.json()
        except Exception as exc:
            errors.append(f"{url}: {exc}")
    joined_errors = " | ".join(errors[:3])
    raise RuntimeError(f"Could not fetch market list from any host: {joined_errors}")


def choose_context_len(config: dict[str, Any]) -> int:
    candidates = [int(item) for item in config.get("candidate_context_lengths_v25", []) if int(item) > 0]
    if not candidates:
        return DEFAULT_CONTEXT_TARGET
    if DEFAULT_CONTEXT_TARGET in candidates:
        return DEFAULT_CONTEXT_TARGET
    return min(candidates, key=lambda item: abs(item - DEFAULT_CONTEXT_TARGET))


def choose_normalize(config: dict[str, Any]) -> bool:
    candidates = [bool(item) for item in config.get("candidate_normalize", [])]
    if True in candidates:
        return True
    return candidates[0] if candidates else True


def next_session_date(last_session: str) -> str:
    anchor = CALENDAR.date_to_session(pd.Timestamp(last_session))
    next_session = CALENDAR.sessions_window(anchor, 2)[1]
    return pd.Timestamp(next_session).strftime("%Y-%m-%d")


def update_status(**updates: Any) -> dict[str, Any]:
    current = read_json(MARKET_SCAN_STATUS_PATH, {})
    next_payload = {**current, **updates}
    write_json(MARKET_SCAN_STATUS_PATH, next_payload)
    return next_payload


def is_hit(abs_error_pct: float | None) -> bool:
    if abs_error_pct is None:
        return False
    return float(abs_error_pct) <= HIT_ERROR_THRESHOLD_PCT


def scan_day_from_generated_at(generated_at: str) -> str:
    raw = str(generated_at or "").strip()
    if not raw:
        return ""
    try:
        return datetime.fromisoformat(raw).astimezone(SHANGHAI_TZ).date().isoformat()
    except ValueError:
        return raw[:10]


def extract_scan_anchor_dates(scan: dict[str, Any]) -> tuple[str | None, str | None]:
    candidates = [
        scan.get("summary", {}).get("overall_predicted_leader"),
        scan.get("summary", {}).get("overall_current_leader"),
        *(scan.get("top_predicted_stocks") or [])[:1],
        *(scan.get("top_current_stocks") or [])[:1],
    ]
    for item in candidates:
        if not isinstance(item, dict):
            continue
        as_of_date = str(item.get("as_of_date") or "").strip() or None
        target_date = str(item.get("target_date") or "").strip() or None
        if as_of_date or target_date:
            return as_of_date, target_date
    return None, None


def build_failure_record(
    item: dict[str, Any],
    requested_source: str | None,
    failure_kind: str,
    failure_reason: str,
    attempted_sources: list[str] | None = None,
    *,
    used_source: str | None = None,
    history_length: int | None = None,
    as_of_date: str | None = None,
    target_date: str | None = None,
    last_close: float | None = None,
) -> dict[str, Any]:
    return {
        "ticker": str(item.get("ticker") or "").strip(),
        "code": str(item.get("code") or "").strip(),
        "name": str(item.get("name") or "").strip() or str(item.get("ticker") or "").strip(),
        "sector": str(item.get("sector") or "未分类").strip() or "未分类",
        "failure_kind": str(failure_kind or "history_fetch_failed").strip() or "history_fetch_failed",
        "failure_reason": str(failure_reason or "Unknown history failure").strip() or "Unknown history failure",
        "requested_history_source": normalize_history_source(requested_source),
        "attempted_sources": [str(source_name) for source_name in (attempted_sources or []) if str(source_name).strip()],
        "used_history_source": str(used_source or "").strip() or None,
        "history_length": int(history_length) if history_length is not None else None,
        "as_of_date": str(as_of_date or "").strip() or None,
        "target_date": str(target_date or "").strip() or None,
        "last_close": float(last_close) if last_close is not None else None,
    }


def inspect_history_candidate(
    item: dict[str, Any],
    period: str,
    history_source: str | None,
) -> dict[str, Any]:
    requested_source = normalize_history_source(history_source)
    ticker = str(item.get("ticker") or "").strip()
    attempted_sources = history_source_order(ticker, requested_source)
    try:
        history = load_history(
            ticker,
            period,
            retries=DEFAULT_HISTORY_RETRIES,
            timeout=DEFAULT_HISTORY_TIMEOUT_SECONDS,
            source=requested_source,
        )
    except Exception as exc:
        return {
            "status": "failed",
            "failure_kind": "history_fetch_failed",
            "failure_reason": str(exc),
            "requested_history_source": requested_source,
            "attempted_sources": attempted_sources,
            "used_history_source": None,
            "history_length": None,
            "as_of_date": None,
            "target_date": None,
            "last_close": None,
            "history_values": None,
        }

    history_length = len(history.index)
    used_source = str(history.attrs.get("history_source") or attempted_sources[0] or requested_source or "auto")
    as_of_date = str(history.iloc[-1]["ds"]) if history_length else None
    target_date = next_session_date(as_of_date) if as_of_date else None
    last_close = float(history.iloc[-1]["values"]) if history_length else None

    if history.empty or history_length < 80:
        return {
            "status": "failed",
            "failure_kind": "history_too_short",
            "failure_reason": f"History length {history_length} < 80 trading rows.",
            "requested_history_source": requested_source,
            "attempted_sources": attempted_sources,
            "used_history_source": used_source,
            "history_length": history_length,
            "as_of_date": as_of_date,
            "target_date": target_date,
            "last_close": last_close,
            "history_values": None,
        }

    values = history["values"].to_numpy(dtype=float)
    return {
        "status": "succeeded",
        "requested_history_source": requested_source,
        "attempted_sources": attempted_sources,
        "used_history_source": used_source,
        "history_length": history_length,
        "as_of_date": as_of_date,
        "target_date": target_date,
        "last_close": last_close,
        "history_values": values,
    }


def summarize_failures(failures: list[dict[str, Any]]) -> dict[str, Any]:
    by_kind: dict[str, int] = {}
    retried_success_count = 0
    retried_failed_count = 0
    for row in failures:
        failure_kind = str(row.get("failure_kind") or "unknown")
        by_kind[failure_kind] = by_kind.get(failure_kind, 0) + 1
        latest_retry = row.get("latest_retry")
        if not isinstance(latest_retry, dict):
            continue
        retry_status = str(latest_retry.get("status") or "").strip()
        if retry_status == "succeeded":
            retried_success_count += 1
        elif retry_status == "failed":
            retried_failed_count += 1
    return {
        "failed_count": len(failures),
        "by_kind": by_kind,
        "retried_success_count": retried_success_count,
        "retried_failed_count": retried_failed_count,
    }


def evaluate_scan_top_pool(scan: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rows = copy.deepcopy(list(scan.get("top_predicted_stocks") or []))
    source = str(scan.get("scan_config", {}).get("history_data_source", "auto"))
    period = str(scan.get("scan_config", {}).get("history_period", "2y"))
    evaluated_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
    history_cache: dict[str, dict[str, float]] = {}
    confirmed_rows: list[dict[str, Any]] = []

    for row in rows:
        ticker = str(row.get("ticker") or "").strip()
        target_date = str(row.get("target_date") or "").strip()
        if not ticker or not target_date:
            row["status"] = "pending"
            continue

        if ticker not in history_cache:
            try:
                history = load_history(
                    ticker,
                    period,
                    retries=DEFAULT_HISTORY_RETRIES,
                    timeout=DEFAULT_HISTORY_TIMEOUT_SECONDS,
                    source=source,
                )
                history_cache[ticker] = {
                    str(item["ds"]): float(item["values"]) for _, item in history.iterrows()
                }
            except Exception:
                history_cache[ticker] = {}

        actual_close = history_cache[ticker].get(target_date)
        if actual_close is None:
            row["status"] = "pending"
            continue

        last_close = safe_float(row.get("last_close"), 0.0)
        predicted_close = safe_float(row.get("predicted_close"), 0.0)
        actual_change_abs = actual_close - last_close
        actual_change_pct = actual_change_abs / max(abs(last_close), 1e-8) * 100.0
        abs_error_pct = abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0

        row["status"] = "evaluated"
        row["actual_close"] = actual_close
        row["actual_change_abs"] = actual_change_abs
        row["actual_change_pct"] = actual_change_pct
        row["abs_error_pct"] = abs_error_pct
        row["direction_hit"] = is_hit(abs_error_pct)
        row["evaluated_at"] = evaluated_at
        confirmed_rows.append(row)

    hit_count = sum(1 for row in confirmed_rows if row.get("direction_hit"))
    backtest_summary = {
        "pool_size": len(rows),
        "confirmed_count": len(confirmed_rows),
        "hit_count": hit_count,
        "hit_rate": hit_count / len(confirmed_rows) if confirmed_rows else 0.0,
        "avg_abs_error_pct": (
            sum(float(row["abs_error_pct"]) for row in confirmed_rows) / len(confirmed_rows)
            if confirmed_rows
            else None
        ),
        "evaluated_at": evaluated_at if confirmed_rows else None,
        "status": "evaluated" if len(confirmed_rows) == len(rows) and rows else "pending",
        "hit_threshold_pct": HIT_ERROR_THRESHOLD_PCT,
    }
    return rows, backtest_summary


def normalize_market_scan_payload(scan: dict[str, Any]) -> dict[str, Any]:
    payload = copy.deepcopy(scan)
    payload["scan_day"] = scan_day_from_generated_at(str(payload.get("generated_at") or ""))
    as_of_date, target_date = extract_scan_anchor_dates(payload)
    if as_of_date:
        payload["as_of_date"] = as_of_date
    if target_date:
        payload["target_date"] = target_date
    top_pool_rows, backtest_summary = evaluate_scan_top_pool(payload)
    payload["top_predicted_stocks"] = top_pool_rows
    payload["backtest_summary"] = backtest_summary
    return payload


def upsert_market_scan_history(scan: dict[str, Any]) -> dict[str, Any]:
    history_bundle = read_json(MARKET_SCAN_HISTORY_PATH, {"entries": []})
    raw_entries = history_bundle.get("entries", [])
    entries: list[dict[str, Any]] = []

    for raw_entry in raw_entries:
        if not isinstance(raw_entry, dict):
            continue
        raw_scan = raw_entry.get("scan")
        if not isinstance(raw_scan, dict):
            continue
        normalized_scan = normalize_market_scan_payload(raw_scan)
        entries.append(
            {
                "scan_day": normalized_scan.get("scan_day"),
                "generated_at": normalized_scan.get("generated_at"),
                "as_of_date": normalized_scan.get("as_of_date"),
                "target_date": normalized_scan.get("target_date"),
                "backtest_summary": normalized_scan.get("backtest_summary"),
                "scan": normalized_scan,
            }
        )

    normalized_scan = normalize_market_scan_payload(scan)
    scan_day = str(normalized_scan.get("scan_day") or "")
    replacement_entry = {
        "scan_day": scan_day,
        "generated_at": normalized_scan.get("generated_at"),
        "as_of_date": normalized_scan.get("as_of_date"),
        "target_date": normalized_scan.get("target_date"),
        "backtest_summary": normalized_scan.get("backtest_summary"),
        "scan": normalized_scan,
    }

    kept_entries = [entry for entry in entries if str(entry.get("scan_day") or "") != scan_day]
    kept_entries.append(replacement_entry)
    kept_entries.sort(
        key=lambda entry: (
            str(entry.get("scan_day") or ""),
            str(entry.get("generated_at") or ""),
        ),
        reverse=True,
    )

    bundle = {
        "updated_at": datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds"),
        "latest_scan_day": scan_day,
        "entries": kept_entries[:MARKET_SCAN_HISTORY_LIMIT],
    }
    write_json(MARKET_SCAN_HISTORY_PATH, bundle)
    return replacement_entry["scan"]


def load_saved_market_scan(scan_day: str | None = None) -> dict[str, Any]:
    requested_scan_day = str(scan_day or "").strip()
    if not requested_scan_day:
        latest_scan = read_json(MARKET_SCAN_PATH, {})
        if isinstance(latest_scan, dict) and latest_scan:
            return normalize_market_scan_payload(latest_scan)

    history_bundle = read_json(MARKET_SCAN_HISTORY_PATH, {"entries": []})
    for raw_entry in history_bundle.get("entries", []):
        if not isinstance(raw_entry, dict):
            continue
        raw_scan = raw_entry.get("scan")
        if not isinstance(raw_scan, dict):
            continue
        normalized_scan = normalize_market_scan_payload(raw_scan)
        candidate_scan_day = str(normalized_scan.get("scan_day") or "")
        if not requested_scan_day or candidate_scan_day == requested_scan_day:
            return normalized_scan

    latest_scan = read_json(MARKET_SCAN_PATH, {})
    if isinstance(latest_scan, dict) and latest_scan:
        normalized_latest = normalize_market_scan_payload(latest_scan)
        if not requested_scan_day or str(normalized_latest.get("scan_day") or "") == requested_scan_day:
            return normalized_latest

    if requested_scan_day:
        raise RuntimeError(f"No saved market scan found for {requested_scan_day}.")
    raise RuntimeError("No saved market scan available.")


def persist_market_scan(scan: dict[str, Any]) -> dict[str, Any]:
    normalized_scan = upsert_market_scan_history(scan)
    latest_scan = read_json(MARKET_SCAN_PATH, {})
    latest_scan_day = scan_day_from_generated_at(str(latest_scan.get("generated_at") or "")) if isinstance(latest_scan, dict) else ""
    if not latest_scan or str(normalized_scan.get("scan_day") or "") == latest_scan_day:
        write_json(MARKET_SCAN_PATH, normalized_scan)
    return normalized_scan


def retry_market_scan_failure(
    ticker: str,
    *,
    scan_day: str | None = None,
    history_source: str | None = None,
) -> dict[str, Any]:
    normalized_ticker = normalize_ticker(ticker)
    scan = load_saved_market_scan(scan_day)
    failures = copy.deepcopy(list(scan.get("failures") or []))
    failure_index = next(
        (
            index
            for index, row in enumerate(failures)
            if normalize_ticker(str(row.get("ticker") or "").strip()) == normalized_ticker
        ),
        -1,
    )
    if failure_index < 0:
        raise RuntimeError(f"{normalized_ticker} is not present in the saved market-scan failure list.")

    period = str(scan.get("scan_config", {}).get("history_period", "2y"))
    requested_source = normalize_history_source(history_source or scan.get("scan_config", {}).get("history_data_source"))
    inspected = inspect_history_candidate(failures[failure_index], period, requested_source)
    retried_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")

    retry_payload = {
        "retried_at": retried_at,
        "requested_history_source": requested_source,
        "attempted_sources": [str(source_name) for source_name in inspected.get("attempted_sources") or []],
        "status": str(inspected.get("status") or "failed"),
        "used_history_source": inspected.get("used_history_source"),
        "history_length": inspected.get("history_length"),
        "as_of_date": inspected.get("as_of_date"),
        "target_date": inspected.get("target_date"),
        "last_close": inspected.get("last_close"),
    }
    if retry_payload["status"] == "failed":
        retry_payload["failure_kind"] = str(inspected.get("failure_kind") or "history_fetch_failed")
        retry_payload["failure_reason"] = str(inspected.get("failure_reason") or "Unknown history failure")

    failures[failure_index]["latest_retry"] = retry_payload
    failures[failure_index]["retry_count"] = int(failures[failure_index].get("retry_count") or 0) + 1
    scan["failures"] = failures
    scan["failure_summary"] = summarize_failures(failures)
    if isinstance(scan.get("summary"), dict):
        scan["summary"]["failure_kind_counts"] = scan["failure_summary"]["by_kind"]
        scan["summary"]["retried_success_count"] = scan["failure_summary"]["retried_success_count"]
        scan["summary"]["retried_failed_count"] = scan["failure_summary"]["retried_failed_count"]
    return persist_market_scan(scan)


def get_model(checkpoint_repo: str) -> timesfm.TimesFM_2p5_200M_torch:
    global BASE_MODEL
    if BASE_MODEL is None:
        BASE_MODEL = timesfm.TimesFM_2p5_200M_torch.from_pretrained(checkpoint_repo)
    return BASE_MODEL


def get_compiled_model(checkpoint_repo: str, context_len: int, horizon_len: int, normalize: bool):
    global CURRENT_COMPILE_KEY
    model = get_model(checkpoint_repo)
    compile_key = (context_len, horizon_len, normalize)
    if CURRENT_COMPILE_KEY != compile_key:
        model.compile(
            timesfm.ForecastConfig(
                max_context=context_len,
                max_horizon=horizon_len,
                normalize_inputs=normalize,
                use_continuous_quantile_head=True,
                force_flip_invariance=True,
                infer_is_positive=True,
                fix_quantile_crossing=True,
            )
        )
        CURRENT_COMPILE_KEY = compile_key
    return model


def quantile_value(full_forecast, batch_index: int, step_index: int, q: float) -> float | None:
    index_map = {0.1: 1, 0.2: 2, 0.3: 3, 0.4: 4, 0.5: 5, 0.6: 6, 0.7: 7, 0.8: 8, 0.9: 9}
    index = index_map.get(q)
    if index is None:
        return None
    try:
        if full_forecast.shape[-1] <= index:
            return None
        return float(full_forecast[batch_index, step_index, index])
    except Exception:
        return None


def fetch_universe_page(page: int) -> list[dict[str, Any]]:
    payload = fetch_market_list_payload(page, UNIVERSE_LIST_PAGE_SIZE)
    rows = payload.get("data", {}).get("diff", [])
    return normalize_universe_rows(rows)


def load_market_universe(limit: int | None = None, force_refresh: bool = False) -> list[dict[str, Any]]:
    if not force_refresh:
        fresh_cached = get_cached_universe(limit=limit)
        if fresh_cached:
            return fresh_cached

    try:
        first_payload = fetch_market_list_payload(1, UNIVERSE_LIST_PAGE_SIZE)
    except Exception:
        stale_cached = get_cached_universe(limit=limit, allow_stale=True)
        if stale_cached:
            update_status(
                stage="loading_universe",
                stage_label="市场清单接口超时，改用缓存股票池继续扫描",
            )
            return stale_cached
        raise

    total = int(first_payload.get("data", {}).get("total", 0))
    first_rows = normalize_universe_rows(first_payload.get("data", {}).get("diff", []))

    if limit and limit > 0 and len(first_rows) >= limit:
        return dedupe_items(first_rows)[:limit]

    total_pages = max(1, math.ceil(total / UNIVERSE_LIST_PAGE_SIZE))
    if limit and limit > 0:
        total_pages = min(total_pages, max(1, math.ceil(limit / UNIVERSE_LIST_PAGE_SIZE)))

    collected = list(first_rows)
    processed_pages = 1
    update_status(
        stage="loading_universe",
        stage_label=f"拉取全市场股票清单（第 {processed_pages}/{total_pages} 页）",
        total=total_pages,
        completed=processed_pages,
        progress_pct=round(
            UNIVERSE_PROGRESS_START
            + (processed_pages / max(total_pages, 1)) * (UNIVERSE_PROGRESS_END - UNIVERSE_PROGRESS_START),
            2,
        ),
    )

    failed_pages: list[int] = []
    try:
        with ThreadPoolExecutor(max_workers=max(1, min(UNIVERSE_FETCH_WORKERS, total_pages - 1 or 1))) as executor:
            futures = {
                executor.submit(fetch_universe_page, page): page
                for page in range(2, total_pages + 1)
            }
            for future in as_completed(futures):
                page = futures[future]
                try:
                    collected.extend(future.result())
                except Exception:
                    failed_pages.append(page)
                processed_pages += 1
                page_note = f"，失败 {len(failed_pages)} 页" if failed_pages else ""
                update_status(
                    stage="loading_universe",
                    stage_label=f"拉取全市场股票清单（第 {processed_pages}/{total_pages} 页{page_note}）",
                    total=total_pages,
                    completed=processed_pages,
                    progress_pct=round(
                        UNIVERSE_PROGRESS_START
                        + (processed_pages / max(total_pages, 1)) * (UNIVERSE_PROGRESS_END - UNIVERSE_PROGRESS_START),
                        2,
                    ),
                )
    except Exception:
        stale_cached = get_cached_universe(limit=limit, allow_stale=True)
        if stale_cached:
            update_status(
                stage="loading_universe",
                stage_label="市场清单分批拉取超时，改用缓存股票池继续扫描",
            )
            return stale_cached
        raise

    items = dedupe_items(collected)
    expected_count = min(int(limit), total) if limit else total
    success_ratio = len(items) / max(expected_count, 1)
    if failed_pages and success_ratio < MIN_UNIVERSE_SUCCESS_RATIO:
        stale_cached = get_cached_universe(limit=limit, allow_stale=True)
        if stale_cached:
            update_status(
                stage="loading_universe",
                stage_label="市场清单缺页较多，改用缓存股票池继续扫描",
            )
            return stale_cached
        raise RuntimeError(
            f"Market list incomplete: fetched {len(items)}/{expected_count} stocks, failed pages={failed_pages[:8]}"
        )

    if failed_pages:
        update_status(
            stage="loading_universe",
            stage_label=f"股票清单已就绪，缺失 {len(failed_pages)} 页，继续扫描已获取的 {len(items)} 只股票",
            total=total_pages,
            completed=processed_pages,
            progress_pct=UNIVERSE_PROGRESS_END,
        )

    if not limit:
        write_json(
            MARKET_UNIVERSE_CACHE_PATH,
            {
                "generated_at_ts": datetime.now(SHANGHAI_TZ).timestamp(),
                "items": items,
            },
        )
    return items[:limit] if limit else items


def load_histories(
    universe: list[dict[str, Any]],
    period: str,
    workers: int,
    history_source: str | None = None,
) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    analyzed: list[dict[str, Any]] = []
    failures: list[dict[str, Any]] = []
    total = len(universe)

    def fetch_item(item: dict[str, Any]) -> dict[str, Any]:
        inspected = inspect_history_candidate(item, period, history_source)
        if str(inspected.get("status") or "") != "succeeded":
            return {
                "ok": False,
                "failure": build_failure_record(
                    item,
                    inspected.get("requested_history_source"),
                    str(inspected.get("failure_kind") or "history_fetch_failed"),
                    str(inspected.get("failure_reason") or "Unknown history failure"),
                    list(inspected.get("attempted_sources") or []),
                    used_source=inspected.get("used_history_source"),
                    history_length=inspected.get("history_length"),
                    as_of_date=inspected.get("as_of_date"),
                    target_date=inspected.get("target_date"),
                    last_close=inspected.get("last_close"),
                ),
            }
        return {
            "ok": True,
            "item": {
                **item,
                "as_of_date": inspected.get("as_of_date"),
                "target_date": inspected.get("target_date"),
                "last_close": float(inspected.get("last_close") or 0.0),
                "history_values": inspected.get("history_values"),
                "used_history_source": inspected.get("used_history_source"),
                "history_length": inspected.get("history_length"),
            },
        }

    with ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
        futures = {executor.submit(fetch_item, item): item for item in universe}
        completed = 0
        for future in as_completed(futures):
            completed += 1
            source_item = futures[future]
            try:
                result = future.result()
                if not result.get("ok"):
                    failures.append(result["failure"])
                else:
                    analyzed.append(result["item"])
            except Exception as exc:
                failures.append(
                    build_failure_record(
                        source_item,
                        history_source,
                        "unexpected_error",
                        str(exc),
                        history_source_order(str(source_item.get("ticker") or ""), history_source),
                    )
                )
            if completed % STATUS_UPDATE_EVERY == 0 or completed == total:
                progress = 8.0 + (completed / max(total, 1)) * 56.0
                update_status(
                    stage="loading_histories",
                    stage_label="拉取全市场历史行情",
                    total=total,
                    completed=completed,
                    progress_pct=round(progress, 2),
                    analyzed_count=len(analyzed),
                    failed_count=len(failures),
                )

    analyzed.sort(key=lambda item: item["ticker"])
    failures.sort(key=lambda item: str(item.get("ticker") or ""))
    return analyzed, failures


def run_market_scan(
    limit: int | None = None,
    workers: int = DEFAULT_FETCH_WORKERS,
    batch_size: int = DEFAULT_BATCH_SIZE,
    force_refresh_universe: bool = False,
):
    started_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
    pid = os.getpid()
    update_status(
        status="running",
        version=MARKET_SCAN_VERSION,
        pid=pid,
        started_at=started_at,
        finished_at=None,
        stage="loading_universe",
        stage_label="拉取全市场股票清单",
        progress_pct=2.0,
        total=0,
        completed=0,
        analyzed_count=0,
        failed_count=0,
        error=None,
        last_generated_at=read_json(MARKET_SCAN_PATH, {}).get("generated_at"),
    )

    try:
        config = ensure_config()
        checkpoint_repo = str(config["v25_checkpoint"])
        context_len = choose_context_len(config)
        normalize = choose_normalize(config)
        universe = load_market_universe(limit=limit, force_refresh=force_refresh_universe)
        update_status(
            total=len(universe),
            completed=0,
            progress_pct=6.0,
            universe_count=len(universe),
            stage="loading_histories",
            stage_label="拉取全市场历史行情",
        )

        analyzed_items, failure_rows = load_histories(
            universe,
            str(config["history_period"]),
            workers,
            history_source=str(config.get("history_data_source", "auto")),
        )
        failed_count = len(failure_rows)
        update_status(
            stage="forecasting",
            stage_label="批量运行 TimesFM 2.5 预测",
            total=len(analyzed_items),
            completed=0,
            progress_pct=66.0,
            analyzed_count=len(analyzed_items),
            failed_count=failed_count,
        )

        model = get_compiled_model(
            checkpoint_repo=checkpoint_repo,
            context_len=context_len,
            horizon_len=1,
            normalize=normalize,
        )

        predictions: list[dict[str, Any]] = []
        for start_index in range(0, len(analyzed_items), max(1, batch_size)):
            batch = analyzed_items[start_index : start_index + max(1, batch_size)]
            point_forecast, quantile_forecast = model.forecast(
                horizon=1,
                inputs=[item["history_values"] for item in batch],
            )
            for batch_index, item in enumerate(batch):
                predicted_close = float(point_forecast[batch_index][0])
                last_close = float(item["last_close"])
                predicted_change_abs = predicted_close - last_close
                predicted_change_pct = predicted_change_abs / max(abs(last_close), 1e-8) * 100.0
                q20_close = quantile_value(quantile_forecast, batch_index, 0, 0.2)
                q80_close = quantile_value(quantile_forecast, batch_index, 0, 0.8)
                confidence_band_pct = (
                    abs(float(q80_close) - float(q20_close)) / max(abs(last_close), 1e-8) * 100.0
                    if q20_close is not None and q80_close is not None
                    else None
                )
                predictions.append(
                    {
                        "ticker": item["ticker"],
                        "code": item["code"],
                        "name": item["name"],
                        "sector": item["sector"] or "未分类",
                        "market_cap": safe_float(item["market_cap"], 0.0),
                        "float_market_cap": safe_float(item["float_market_cap"], 0.0),
                        "current_price": safe_float(item["current_price"], 0.0),
                        "current_change_pct": safe_float(item["current_change_pct"], 0.0),
                        "as_of_date": item["as_of_date"],
                        "target_date": item["target_date"],
                        "last_close": last_close,
                        "used_history_source": item.get("used_history_source"),
                        "history_length": item.get("history_length"),
                        "predicted_close": predicted_close,
                        "predicted_change_abs": predicted_change_abs,
                        "predicted_change_pct": predicted_change_pct,
                        "q20_close": q20_close,
                        "q80_close": q80_close,
                        "confidence_band_pct": confidence_band_pct,
                    }
                )
            progress = 66.0 + (len(predictions) / max(len(analyzed_items), 1)) * 28.0
            update_status(
                stage="forecasting",
                stage_label="批量运行 TimesFM 2.5 预测",
                total=len(analyzed_items),
                completed=len(predictions),
                progress_pct=round(progress, 2),
                analyzed_count=len(analyzed_items),
                failed_count=failed_count,
            )

        sectors: dict[str, dict[str, Any]] = {}
        for item in predictions:
            sector_name = str(item["sector"] or "未分类")
            sector = sectors.get(
                sector_name,
                {
                    "sector": sector_name,
                    "stock_count": 0,
                    "market_cap_total": 0.0,
                    "weighted_prediction_sum": 0.0,
                    "weighted_current_sum": 0.0,
                    "bullish_count": 0,
                    "bearish_count": 0,
                    "leader_current": None,
                    "leader_predicted": None,
                    "top_stocks": [],
                },
            )
            weight = max(safe_float(item["market_cap"], 0.0), 1.0)
            sector["stock_count"] += 1
            sector["market_cap_total"] += safe_float(item["market_cap"], 0.0)
            sector["weighted_prediction_sum"] += safe_float(item["predicted_change_pct"], 0.0) * weight
            sector["weighted_current_sum"] += safe_float(item["current_change_pct"], 0.0) * weight
            if safe_float(item["predicted_change_pct"], 0.0) >= 0:
                sector["bullish_count"] += 1
            if safe_float(item["predicted_change_pct"], 0.0) < 0:
                sector["bearish_count"] += 1
            if sector["leader_current"] is None or (
                safe_float(item["current_change_pct"], -999.0) > safe_float(sector["leader_current"]["current_change_pct"], -999.0)
            ):
                sector["leader_current"] = item
            if sector["leader_predicted"] is None or (
                safe_float(item["predicted_change_pct"], -999.0) > safe_float(sector["leader_predicted"]["predicted_change_pct"], -999.0)
            ):
                sector["leader_predicted"] = item
            sector["top_stocks"].append(item)
            sectors[sector_name] = sector

        sector_rows: list[dict[str, Any]] = []
        for sector in sectors.values():
            top_stocks = sorted(
                sector["top_stocks"],
                key=lambda item: (
                    safe_float(item["predicted_change_pct"], 0.0),
                    safe_float(item["current_change_pct"], 0.0),
                    safe_float(item["market_cap"], 0.0),
                ),
                reverse=True,
            )[:12]
            market_cap_total = safe_float(sector["market_cap_total"], 0.0)
            avg_predicted_change_pct = sector["weighted_prediction_sum"] / max(market_cap_total, 1.0)
            avg_current_change_pct = sector["weighted_current_sum"] / max(market_cap_total, 1.0)
            bullish_ratio = sector["bullish_count"] / max(sector["stock_count"], 1)
            sector_rows.append(
                {
                    "sector": sector["sector"],
                    "stock_count": sector["stock_count"],
                    "market_cap_total": market_cap_total,
                    "avg_predicted_change_pct": avg_predicted_change_pct,
                    "avg_current_change_pct": avg_current_change_pct,
                    "bullish_ratio": bullish_ratio,
                    "leader_current": sector["leader_current"],
                    "leader_predicted": sector["leader_predicted"],
                    "top_stocks": top_stocks,
                    "heat_score": avg_predicted_change_pct * 0.7 + avg_current_change_pct * 0.3,
                }
            )

        sector_rows.sort(
            key=lambda item: (
                safe_float(item["market_cap_total"], 0.0),
                safe_float(item["avg_predicted_change_pct"], 0.0),
            ),
            reverse=True,
        )
        strongest_sector = max(sector_rows, key=lambda item: safe_float(item["avg_predicted_change_pct"], -999.0), default=None)
        weakest_sector = min(sector_rows, key=lambda item: safe_float(item["avg_predicted_change_pct"], 999.0), default=None)
        failure_summary = summarize_failures(failure_rows)
        overall_predicted_leader = max(
            predictions,
            key=lambda item: (
                safe_float(item["predicted_change_pct"], -999.0),
                safe_float(item["current_change_pct"], -999.0),
            ),
            default=None,
        )
        overall_current_leader = max(
            predictions,
            key=lambda item: (
                safe_float(item["current_change_pct"], -999.0),
                safe_float(item["predicted_change_pct"], -999.0),
            ),
            default=None,
        )

        generated_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
        payload = {
            "generated_at": generated_at,
            "model_version": "2.5",
            "scan_version": MARKET_SCAN_VERSION,
            "scan_mode": "full_market",
            "scan_config": {
                "checkpoint_repo": checkpoint_repo,
                "context_len": context_len,
                "normalize": normalize,
                "history_period": str(config["history_period"]),
                "history_data_source": str(config.get("history_data_source", "auto")),
                "horizon_len": 1,
                "requested_universe_count": len(universe),
                "analyzed_count": len(predictions),
                "failed_count": failed_count,
            },
            "failure_summary": failure_summary,
            "summary": {
                "universe_count": len(universe),
                "analyzed_count": len(predictions),
                "failed_count": failed_count,
                "failure_kind_counts": failure_summary["by_kind"],
                "retried_success_count": failure_summary["retried_success_count"],
                "retried_failed_count": failure_summary["retried_failed_count"],
                "sector_count": len(sector_rows),
                "bullish_stock_count": len([item for item in predictions if safe_float(item["predicted_change_pct"], 0.0) >= 0]),
                "bearish_stock_count": len([item for item in predictions if safe_float(item["predicted_change_pct"], 0.0) < 0]),
                "strongest_sector": strongest_sector,
                "weakest_sector": weakest_sector,
                "overall_predicted_leader": overall_predicted_leader,
                "overall_current_leader": overall_current_leader,
            },
            "failures": failure_rows,
            "sectors": sector_rows,
            "top_predicted_stocks": sorted(
                predictions,
                key=lambda item: (
                    safe_float(item["predicted_change_pct"], -999.0),
                    safe_float(item["current_change_pct"], -999.0),
                ),
                reverse=True,
            )[:30],
            "top_current_stocks": sorted(
                predictions,
                key=lambda item: (
                    safe_float(item["current_change_pct"], -999.0),
                    safe_float(item["predicted_change_pct"], -999.0),
                ),
                reverse=True,
            )[:30],
        }

        payload = upsert_market_scan_history(payload)
        write_json(MARKET_SCAN_PATH, payload)
        update_status(
            status="succeeded",
            version=MARKET_SCAN_VERSION,
            pid=pid,
            started_at=started_at,
            finished_at=generated_at,
            stage="completed",
            stage_label="全市场扫描完成",
            total=len(predictions),
            completed=len(predictions),
            progress_pct=100.0,
            analyzed_count=len(predictions),
            failed_count=failed_count,
            error=None,
            last_generated_at=generated_at,
        )
        return payload
    except Exception as exc:
        finished_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
        update_status(
            status="failed",
            version=MARKET_SCAN_VERSION,
            pid=pid,
            finished_at=finished_at,
            stage="failed",
            stage_label="全市场扫描失败",
            error={
                "message": str(exc),
                "traceback": traceback.format_exc(limit=12),
            },
        )
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description="Run full-market TimesFM 2.5 scan.")
    parser.add_argument("--limit", type=int, default=0, help="Optional limit for testing")
    parser.add_argument("--workers", type=int, default=DEFAULT_FETCH_WORKERS, help="History fetch worker count")
    parser.add_argument("--batch-size", type=int, default=DEFAULT_BATCH_SIZE, help="Forecast batch size")
    parser.add_argument("--refresh-universe", action="store_true", help="Force refresh the full market universe cache")
    parser.add_argument("--retry-failure-ticker", default="", help="Retry one saved market-scan failure by ticker")
    parser.add_argument("--scan-day", default="", help="Optional saved scan day when retrying a failure")
    parser.add_argument("--history-source", default="", help="Optional history source override when retrying a failure")
    args = parser.parse_args()
    if args.retry_failure_ticker.strip():
        payload = retry_market_scan_failure(
            args.retry_failure_ticker,
            scan_day=args.scan_day.strip() or None,
            history_source=args.history_source.strip() or None,
        )
    else:
        payload = run_market_scan(
            limit=args.limit if args.limit > 0 else None,
            workers=max(1, args.workers),
            batch_size=max(1, args.batch_size),
            force_refresh_universe=args.refresh_universe,
        )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
