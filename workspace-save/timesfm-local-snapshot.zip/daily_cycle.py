from __future__ import annotations

import argparse
import json
import uuid
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd
import timesfm

from cycle_shared import (
    CALENDAR,
    SHANGHAI_TZ,
    V1_DASHBOARD_PATH,
    V1_PREDICTIONS_PATH,
    V1_RUNS_PATH,
    config_payload,
    ensure_config,
    load_history,
    normalize_ticker,
    read_json,
    resolve_active_watchlist,
    write_json,
)


MODEL_CACHE: dict[tuple[str, int], timesfm.TimesFm] = {}
MODEL_LABEL = "TimesFM 1.0"


def get_model(checkpoint_repo: str, horizon_len: int) -> timesfm.TimesFm:
    cache_key = (checkpoint_repo, horizon_len)
    if cache_key in MODEL_CACHE:
        return MODEL_CACHE[cache_key]

    model = timesfm.TimesFm(
        hparams=timesfm.TimesFmHparams(
            backend="cpu",
            per_core_batch_size=32,
            horizon_len=horizon_len,
        ),
        checkpoint=timesfm.TimesFmCheckpoint(huggingface_repo_id=checkpoint_repo),
    )
    MODEL_CACHE[cache_key] = model
    return model


def sign_of(value: float, flat_threshold: float = 1e-8) -> int:
    if abs(value) <= flat_threshold:
        return 0
    return 1 if value > 0 else -1


def quantile_value(model: timesfm.TimesFm, full_forecast: np.ndarray, step_index: int, q: float) -> float | None:
    for idx, quantile in enumerate(model.quantiles):
        if abs(float(quantile) - q) < 1e-8:
            return float(full_forecast[0, step_index, 1 + idx])
    return None


def score_candidate(
    model: timesfm.TimesFm,
    values: np.ndarray,
    dates: list[str],
    context_len: int,
    normalize: bool,
    backtest_days: int,
) -> dict[str, Any]:
    usable_days = min(backtest_days, max(len(values) - 40, 0))
    if usable_days <= 0:
        return {
            "score": float("-inf"),
            "direction_accuracy": 0.0,
            "mae_pct": float("inf"),
            "sample_size": 0,
            "normalize": normalize,
            "context_len": context_len,
        }

    hits = 0
    abs_errors: list[float] = []
    for offset in range(usable_days, 0, -1):
        history = values[:-offset]
        actual_close = float(values[-offset])
        prev_close = float(history[-1])
        point_forecast, _ = model.forecast(
            [history],
            freq=[0],
            forecast_context_len=context_len,
            normalize=normalize,
        )
        predicted_close = float(point_forecast[0][0])
        predicted_change = predicted_close - prev_close
        actual_change = actual_close - prev_close
        hits += int(sign_of(predicted_change) == sign_of(actual_change))
        abs_errors.append(abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0)

    sample_size = len(abs_errors)
    direction_accuracy = hits / sample_size if sample_size else 0.0
    mae_pct = sum(abs_errors) / sample_size if sample_size else float("inf")
    return {
        "score": direction_accuracy * 100.0 - mae_pct * 2.0,
        "direction_accuracy": direction_accuracy,
        "mae_pct": mae_pct,
        "sample_size": sample_size,
        "normalize": normalize,
        "context_len": context_len,
    }


def next_sessions(last_session: str, count: int) -> list[str]:
    anchor = CALENDAR.date_to_session(pd.Timestamp(last_session))
    return [
        pd.Timestamp(session).strftime("%Y-%m-%d")
        for session in CALENDAR.sessions_window(anchor, count + 1)[1:]
    ]


def generate_for_ticker(
    watch_item: dict[str, Any],
    config: dict[str, Any],
    history: pd.DataFrame,
    generated_at: str,
) -> list[dict[str, Any]]:
    values = history["values"].to_numpy(dtype=float)
    dates = history["ds"].tolist()
    as_of_date = dates[-1]
    checkpoint_repo = str(config["v1_checkpoint"])
    model = get_model(checkpoint_repo=checkpoint_repo, horizon_len=int(config["horizon_len"]))

    candidate_results: list[dict[str, Any]] = []
    selected_strategy: dict[str, Any] | None = None
    for context_len in config["candidate_context_lengths_v1"]:
        for normalize in config["candidate_normalize"]:
            result = score_candidate(
                model=model,
                values=values,
                dates=dates,
                context_len=int(context_len),
                normalize=bool(normalize),
                backtest_days=int(config["backtest_days"]),
            )
            result["checkpoint_repo"] = checkpoint_repo
            candidate_results.append(result)
            if selected_strategy is None or float(result["score"]) > float(selected_strategy["score"]):
                selected_strategy = result

    if selected_strategy is None:
        raise RuntimeError(f"Could not select a strategy for {watch_item['ticker']}.")

    point_forecast, full_forecast = model.forecast(
        [values],
        freq=[0],
        forecast_context_len=int(selected_strategy["context_len"]),
        normalize=bool(selected_strategy["normalize"]),
    )

    future_dates = next_sessions(as_of_date, int(config["horizon_len"]))
    last_close = float(values[-1])
    run_id = uuid.uuid4().hex
    rows: list[dict[str, Any]] = []
    for step_index, target_date in enumerate(future_dates):
        predicted_close = float(point_forecast[0][step_index])
        predicted_change_abs = predicted_close - last_close
        predicted_change_pct = predicted_change_abs / max(abs(last_close), 1e-8) * 100.0
        rows.append(
            {
                "id": f"v1|{watch_item['ticker']}|{as_of_date}|{target_date}|{step_index + 1}",
                "run_id": run_id,
                "model_version": "1.0",
                "model_family": MODEL_LABEL,
                "ticker": watch_item["ticker"],
                "name": watch_item["name"],
                "source_pool": watch_item["source_pool"],
                "source_tags": watch_item["source_tags"],
                "as_of_date": as_of_date,
                "target_date": target_date,
                "horizon_step": step_index + 1,
                "generated_at": generated_at,
                "last_close": last_close,
                "predicted_close": predicted_close,
                "predicted_change_abs": predicted_change_abs,
                "predicted_change_pct": predicted_change_pct,
                "q20_close": quantile_value(model, full_forecast, step_index, 0.2),
                "q50_close": quantile_value(model, full_forecast, step_index, 0.5),
                "q80_close": quantile_value(model, full_forecast, step_index, 0.8),
                "checkpoint_repo": checkpoint_repo,
                "context_len": int(selected_strategy["context_len"]),
                "normalize": bool(selected_strategy["normalize"]),
                "backtest_score": float(selected_strategy["score"]),
                "backtest_direction_accuracy": float(selected_strategy["direction_accuracy"]),
                "backtest_mae_pct": float(selected_strategy["mae_pct"]),
                "backtest_sample_size": int(selected_strategy["sample_size"]),
                "candidate_results": sorted(candidate_results, key=lambda item: float(item["score"]), reverse=True)[:5],
                "status": "pending",
                "actual_close": None,
                "actual_change_abs": None,
                "actual_change_pct": None,
                "abs_error_pct": None,
                "direction_hit": None,
                "evaluated_at": None,
            }
        )
    return rows


def evaluate_predictions(
    predictions: list[dict[str, Any]],
    history_map: dict[str, dict[str, float]],
    generated_at: str,
) -> int:
    updated = 0
    for record in predictions:
        if record.get("status") == "evaluated":
            continue
        actual_close = history_map.get(str(record["ticker"]), {}).get(str(record["target_date"]))
        if actual_close is None:
            continue
        last_close = float(record["last_close"])
        predicted_close = float(record["predicted_close"])
        actual_change_abs = actual_close - last_close
        predicted_change_abs = float(record["predicted_change_abs"])
        record["actual_close"] = actual_close
        record["actual_change_abs"] = actual_change_abs
        record["actual_change_pct"] = actual_change_abs / max(abs(last_close), 1e-8) * 100.0
        record["abs_error_pct"] = abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0
        record["direction_hit"] = sign_of(predicted_change_abs) == sign_of(actual_change_abs)
        record["status"] = "evaluated"
        record["evaluated_at"] = generated_at
        updated += 1
    return updated


def latest_next_day_predictions(predictions: list[dict[str, Any]], active_watchlist: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latest_by_ticker: dict[str, dict[str, Any]] = {}
    for record in sorted(
        [item for item in predictions if int(item["horizon_step"]) == 1],
        key=lambda item: (str(item["as_of_date"]), str(item["generated_at"])),
        reverse=True,
    ):
        ticker = str(record["ticker"])
        if ticker not in latest_by_ticker:
            latest_by_ticker[ticker] = record
    watch_order = {item["ticker"]: index for index, item in enumerate(active_watchlist)}
    return sorted(latest_by_ticker.values(), key=lambda item: watch_order.get(str(item["ticker"]), 9999))


def recent_confirmations(predictions: list[dict[str, Any]], limit: int = 30) -> list[dict[str, Any]]:
    confirmed = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") == "evaluated"
    ]
    return sorted(confirmed, key=lambda item: str(item["target_date"]), reverse=True)[:limit]


def compute_metrics(predictions: list[dict[str, Any]]) -> dict[str, Any]:
    confirmed = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") == "evaluated"
    ]
    recent = sorted(confirmed, key=lambda item: str(item["target_date"]), reverse=True)[:20]
    pending = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") != "evaluated"
    ]
    direction_accuracy = 0.0
    avg_abs_error_pct = 0.0
    if recent:
        direction_accuracy = sum(1 for item in recent if item.get("direction_hit")) / len(recent)
        avg_abs_error_pct = sum(float(item["abs_error_pct"]) for item in recent) / len(recent)
    return {
        "confirmed_count": len(confirmed),
        "recent_confirmed_count": len(recent),
        "recent_direction_accuracy": direction_accuracy,
        "recent_avg_abs_error_pct": avg_abs_error_pct,
        "pending_next_day_count": len(pending),
    }


def build_dashboard(
    config: dict[str, Any],
    predictions: list[dict[str, Any]],
    active_watchlist: list[dict[str, Any]],
    generated_at: str,
) -> dict[str, Any]:
    next_day = latest_next_day_predictions(predictions, active_watchlist)
    return {
        "generated_at": generated_at,
        "model_version": "1.0",
        "model_family": MODEL_LABEL,
        "config": config_payload(config, active_watchlist),
        "metrics": compute_metrics(predictions),
        "bullish_count": sum(1 for item in next_day if float(item["predicted_change_pct"]) > 0),
        "bearish_count": sum(1 for item in next_day if float(item["predicted_change_pct"]) < 0),
        "next_day_predictions": next_day,
        "recent_confirmations": recent_confirmations(predictions),
        "prediction_count": len(predictions),
    }


def run_daily_cycle(filter_tickers: set[str] | None = None) -> dict[str, Any]:
    generated_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
    config = ensure_config()
    active_watchlist = resolve_active_watchlist(config)
    if filter_tickers is not None:
        active_watchlist = [item for item in active_watchlist if item["ticker"] in filter_tickers]

    predictions: list[dict[str, Any]] = read_json(V1_PREDICTIONS_PATH, [])
    runs: list[dict[str, Any]] = read_json(V1_RUNS_PATH, [])
    histories: dict[str, pd.DataFrame] = {}
    history_map: dict[str, dict[str, float]] = {}

    for watch_item in active_watchlist:
        history = load_history(
            watch_item["ticker"],
            config["history_period"],
            source=config.get("history_data_source"),
        )
        histories[watch_item["ticker"]] = history
        history_map[watch_item["ticker"]] = {
            str(row["ds"]): float(row["values"]) for _, row in history.iterrows()
        }

    evaluated_count = evaluate_predictions(predictions, history_map, generated_at)

    for watch_item in active_watchlist:
        as_of_date = str(histories[watch_item["ticker"]].iloc[-1]["ds"])
        predictions = [
            item
            for item in predictions
            if not (
                str(item["ticker"]) == watch_item["ticker"]
                and str(item["as_of_date"]) == as_of_date
                and str(item.get("model_version")) == "1.0"
            )
        ]
        predictions.extend(generate_for_ticker(watch_item, config, histories[watch_item["ticker"]], generated_at))

    predictions = sorted(
        predictions,
        key=lambda item: (str(item["as_of_date"]), int(item["horizon_step"]), str(item["ticker"])),
    )
    dashboard = build_dashboard(config, predictions, active_watchlist, generated_at)
    runs.append(
        {
            "generated_at": generated_at,
            "model_version": "1.0",
            "tickers": [item["ticker"] for item in active_watchlist],
            "evaluated_count": evaluated_count,
            "prediction_count": len([item for item in predictions if item["generated_at"] == generated_at]),
            "metrics": dashboard["metrics"],
        }
    )

    write_json(V1_PREDICTIONS_PATH, predictions)
    write_json(V1_DASHBOARD_PATH, dashboard)
    write_json(V1_RUNS_PATH, runs[-100:])
    return dashboard


def main() -> None:
    parser = argparse.ArgumentParser(description="Run TimesFM 1.0 A-share daily cycle.")
    parser.add_argument("--tickers", default="", help="Optional comma-separated ticker filter")
    args = parser.parse_args()
    filter_tickers = None
    if args.tickers.strip():
        filter_tickers = {normalize_ticker(item) for item in args.tickers.split(",") if item.strip()}
    print(json.dumps(run_daily_cycle(filter_tickers=filter_tickers), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
