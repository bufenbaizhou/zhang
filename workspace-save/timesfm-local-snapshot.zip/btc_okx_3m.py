from __future__ import annotations

import argparse
import json
import math
from datetime import datetime
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import requests
import timesfm

from cycle_shared import SHANGHAI_TZ, ensure_config


OKX_HISTORY_CANDLES_URL = "https://www.okx.com/api/v5/market/history-candles"
DEFAULT_INST_ID = "BTC-USD-SWAP"
DEFAULT_BAR = "1m"
DEFAULT_LIMIT = 180
DEFAULT_HORIZON_MINUTES = 3
DEFAULT_BACKTEST_WINDOWS = 30
DEFAULT_STRATEGY_MAX_AGE_MINUTES = 30
MODEL_LABEL = "TimesFM 2.5"
STRATEGY_STATE_PATH = Path(__file__).resolve().parent / "data" / "btc_okx_3m_state.json"

BASE_MODEL: timesfm.TimesFM_2p5_200M_torch | None = None
CURRENT_COMPILE_KEY: tuple[int, int, bool] | None = None


def get_model(checkpoint_repo: str) -> timesfm.TimesFM_2p5_200M_torch:
    global BASE_MODEL
    if BASE_MODEL is None:
        BASE_MODEL = timesfm.TimesFM_2p5_200M_torch.from_pretrained(checkpoint_repo)
    return BASE_MODEL


def get_compiled_model(checkpoint_repo: str, context_len: int, horizon_len: int, normalize: bool):
    global CURRENT_COMPILE_KEY
    model = get_model(checkpoint_repo)
    compile_key = (context_len, horizon_len, normalize)
    if CURRENT_COMPILE_KEY != compile_key:
        model.compile(
            timesfm.ForecastConfig(
                max_context=context_len,
                max_horizon=horizon_len,
                normalize_inputs=normalize,
                use_continuous_quantile_head=True,
                force_flip_invariance=True,
                infer_is_positive=True,
                fix_quantile_crossing=True,
            )
        )
        CURRENT_COMPILE_KEY = compile_key
    return model


def sign_of(value: float, flat_threshold: float = 1e-8) -> int:
    if abs(value) <= flat_threshold:
        return 0
    return 1 if value > 0 else -1


def quantile_value(full_forecast: np.ndarray, step_index: int, q: float) -> float | None:
    index_map = {0.1: 1, 0.2: 2, 0.3: 3, 0.4: 4, 0.5: 5, 0.6: 6, 0.7: 7, 0.8: 8, 0.9: 9}
    index = index_map.get(q)
    if index is None or full_forecast.shape[-1] <= index:
        return None
    return float(full_forecast[0, step_index, index])


def fetch_okx_candles(inst_id: str, bar: str, limit: int) -> pd.DataFrame:
    response = requests.get(
        OKX_HISTORY_CANDLES_URL,
        params={"instId": inst_id, "bar": bar, "limit": str(limit)},
        headers={"User-Agent": "Mozilla/5.0"},
        timeout=15,
    )
    response.raise_for_status()
    payload = response.json()
    if str(payload.get("code")) != "0":
        raise RuntimeError(f"OKX market data error: {payload.get('msg') or payload}")

    records: list[dict[str, Any]] = []
    for row in payload.get("data", []):
        if not isinstance(row, list) or len(row) < 9:
            continue
        if str(row[8]) != "1":
            continue
        ts_ms = int(row[0])
        records.append(
            {
                "ts_ms": ts_ms,
                "ts_iso": datetime.fromtimestamp(ts_ms / 1000, tz=SHANGHAI_TZ).isoformat(timespec="seconds"),
                "open": float(row[1]),
                "high": float(row[2]),
                "low": float(row[3]),
                "close": float(row[4]),
                "volume_contracts": float(row[5]),
                "volume_base": float(row[6]),
                "volume_quote": float(row[7]),
            }
        )
    if len(records) < 90:
        raise RuntimeError(f"Not enough confirmed OKX candles for {inst_id}: {len(records)}")
    frame = pd.DataFrame.from_records(records).sort_values("ts_ms").reset_index(drop=True)
    return frame


def scaled_realized_sigma_pct(values: np.ndarray, return_window: int, horizon_steps: int) -> float | None:
    if len(values) < return_window + 1:
        return None
    log_returns = np.diff(np.log(values))
    if len(log_returns) < return_window:
        return None
    sigma = float(np.std(log_returns[-return_window:], ddof=0))
    return sigma * math.sqrt(max(horizon_steps, 1)) * 100.0


def choose_context_lengths(config: dict[str, Any]) -> list[int]:
    configured = [int(item) for item in config.get("candidate_context_lengths_v25", []) if int(item) > 0]
    merged = sorted(set([64, 96, 128] + [item for item in configured if item <= 256]))
    return merged or [64, 128]


def choose_normalize_candidates(config: dict[str, Any]) -> list[bool]:
    values = [bool(item) for item in config.get("candidate_normalize", [True, False])]
    return values or [True, False]


def load_strategy_state() -> dict[str, Any] | None:
    if not STRATEGY_STATE_PATH.exists():
        return None
    try:
        payload = json.loads(STRATEGY_STATE_PATH.read_text(encoding="utf-8"))
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def save_strategy_state(payload: dict[str, Any]) -> None:
    STRATEGY_STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STRATEGY_STATE_PATH.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def strategy_state_is_fresh(
    payload: dict[str, Any] | None,
    *,
    checkpoint_repo: str,
    inst_id: str,
    bar: str,
    horizon_minutes: int,
    strategy_max_age_minutes: int,
) -> bool:
    if not payload:
        return False
    if str(payload.get("checkpoint_repo") or "") != checkpoint_repo:
        return False
    if str(payload.get("inst_id") or "") != inst_id:
        return False
    if str(payload.get("bar") or "") != bar:
        return False
    if int(payload.get("horizon_minutes") or 0) != int(horizon_minutes):
        return False
    if int(payload.get("context_len") or 0) <= 0:
        return False
    refreshed_at = str(payload.get("refreshed_at") or "").strip()
    if not refreshed_at:
        return False
    try:
        refreshed_dt = datetime.fromisoformat(refreshed_at)
    except ValueError:
        return False
    age_seconds = (datetime.now(SHANGHAI_TZ) - refreshed_dt).total_seconds()
    return age_seconds <= max(strategy_max_age_minutes, 1) * 60


def score_candidate(
    checkpoint_repo: str,
    values: np.ndarray,
    context_len: int,
    normalize: bool,
    backtest_windows: int,
    horizon_steps: int,
) -> dict[str, Any]:
    max_anchor = len(values) - horizon_steps
    usable = min(backtest_windows, max(max_anchor - 60, 0))
    if usable <= 0:
        return {
            "score": float("-inf"),
            "direction_accuracy": 0.0,
            "mae_pct": float("inf"),
            "sample_size": 0,
            "normalize": normalize,
            "context_len": context_len,
        }

    model = get_compiled_model(
        checkpoint_repo=checkpoint_repo,
        context_len=context_len,
        horizon_len=horizon_steps,
        normalize=normalize,
    )

    hits = 0
    abs_errors: list[float] = []
    start_anchor = max(40, max_anchor - usable)
    for anchor in range(start_anchor, max_anchor):
        history = values[: anchor + 1]
        prev_close = float(history[-1])
        actual_close = float(values[anchor + horizon_steps])
        point_forecast, _ = model.forecast(horizon=horizon_steps, inputs=[history])
        predicted_close = float(point_forecast[0][horizon_steps - 1])
        hits += int(sign_of(predicted_close - prev_close) == sign_of(actual_close - prev_close))
        abs_errors.append(abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0)

    sample_size = len(abs_errors)
    direction_accuracy = hits / sample_size if sample_size else 0.0
    mae_pct = sum(abs_errors) / sample_size if sample_size else float("inf")
    return {
        "score": direction_accuracy * 100.0 - mae_pct * 2.0,
        "direction_accuracy": direction_accuracy,
        "mae_pct": mae_pct,
        "sample_size": sample_size,
        "normalize": normalize,
        "context_len": context_len,
    }


def predict_btc_change(
    inst_id: str,
    bar: str,
    limit: int,
    horizon_minutes: int,
    backtest_windows: int,
    strategy_max_age_minutes: int,
    force_reselect: bool,
) -> dict[str, Any]:
    config = ensure_config()
    checkpoint_repo = str(config["v25_checkpoint"])
    candles = fetch_okx_candles(inst_id=inst_id, bar=bar, limit=limit)
    values = candles["close"].to_numpy(dtype=float)
    last_close = float(values[-1])
    last_ts_ms = int(candles.iloc[-1]["ts_ms"])

    strategy_state = load_strategy_state()
    candidate_results: list[dict[str, Any]] = []
    selected_strategy: dict[str, Any] | None = None
    strategy_selection_mode = "full_backtest"
    strategy_refreshed_at = None

    if not force_reselect and strategy_state_is_fresh(
        strategy_state,
        checkpoint_repo=checkpoint_repo,
        inst_id=inst_id,
        bar=bar,
        horizon_minutes=horizon_minutes,
        strategy_max_age_minutes=strategy_max_age_minutes,
    ):
        selected_strategy = {
            "score": float(strategy_state.get("score") or 0.0),
            "direction_accuracy": float(strategy_state.get("direction_accuracy") or 0.0),
            "mae_pct": float(strategy_state.get("mae_pct") or 0.0),
            "sample_size": int(strategy_state.get("sample_size") or 0),
            "normalize": bool(strategy_state.get("normalize")),
            "context_len": int(strategy_state.get("context_len") or 0),
            "checkpoint_repo": checkpoint_repo,
        }
        raw_candidates = strategy_state.get("candidate_results")
        candidate_results = list(raw_candidates) if isinstance(raw_candidates, list) else []
        strategy_selection_mode = "cached_strategy"
        strategy_refreshed_at = str(strategy_state.get("refreshed_at") or "") or None
    else:
        for context_len in choose_context_lengths(config):
            for normalize in choose_normalize_candidates(config):
                result = score_candidate(
                    checkpoint_repo=checkpoint_repo,
                    values=values,
                    context_len=context_len,
                    normalize=normalize,
                    backtest_windows=backtest_windows,
                    horizon_steps=horizon_minutes,
                )
                result["checkpoint_repo"] = checkpoint_repo
                candidate_results.append(result)
                if selected_strategy is None or float(result["score"]) > float(selected_strategy["score"]):
                    selected_strategy = result
        strategy_refreshed_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")

    if selected_strategy is None:
        raise RuntimeError("Could not select a short-horizon BTC strategy.")

    if strategy_selection_mode == "full_backtest":
        save_strategy_state(
            {
                "refreshed_at": strategy_refreshed_at,
                "checkpoint_repo": checkpoint_repo,
                "inst_id": inst_id,
                "bar": bar,
                "horizon_minutes": int(horizon_minutes),
                "context_len": int(selected_strategy["context_len"]),
                "normalize": bool(selected_strategy["normalize"]),
                "score": float(selected_strategy["score"]),
                "direction_accuracy": float(selected_strategy["direction_accuracy"]),
                "mae_pct": float(selected_strategy["mae_pct"]),
                "sample_size": int(selected_strategy["sample_size"]),
                "candidate_results": sorted(candidate_results, key=lambda item: float(item["score"]), reverse=True)[:6],
            }
        )

    model = get_compiled_model(
        checkpoint_repo=checkpoint_repo,
        context_len=int(selected_strategy["context_len"]),
        horizon_len=horizon_minutes,
        normalize=bool(selected_strategy["normalize"]),
    )
    point_forecast, quantile_forecast = model.forecast(horizon=horizon_minutes, inputs=[values])

    path_rows: list[dict[str, Any]] = []
    for step_index in range(horizon_minutes):
        predicted_close = float(point_forecast[0][step_index])
        q20_close = quantile_value(quantile_forecast, step_index, 0.2)
        q80_close = quantile_value(quantile_forecast, step_index, 0.8)
        target_ts_ms = last_ts_ms + (step_index + 1) * 60_000
        path_rows.append(
            {
                "minute_offset": step_index + 1,
                "target_ts_ms": target_ts_ms,
                "target_time": datetime.fromtimestamp(target_ts_ms / 1000, tz=SHANGHAI_TZ).isoformat(timespec="seconds"),
                "predicted_close": predicted_close,
                "predicted_change_abs": predicted_close - last_close,
                "predicted_change_pct": (predicted_close - last_close) / max(abs(last_close), 1e-8) * 100.0,
                "q20_close": q20_close,
                "q80_close": q80_close,
                "band_pct": (
                    abs(float(q80_close) - float(q20_close)) / max(abs(last_close), 1e-8) * 100.0
                    if q20_close is not None and q80_close is not None
                    else None
                ),
            }
        )

    final_row = path_rows[-1]
    predicted_sigma_3m_pct = None
    if final_row["q20_close"] is not None and final_row["q80_close"] is not None:
        predicted_sigma_3m_pct = abs(float(final_row["q80_close"]) - float(final_row["q20_close"])) / (
            1.683 * max(abs(last_close), 1e-8)
        ) * 100.0

    realized_sigma_3m_pct_5m = scaled_realized_sigma_pct(values, 5, horizon_minutes)
    realized_sigma_3m_pct_15m = scaled_realized_sigma_pct(values, 15, horizon_minutes)
    realized_sigma_3m_pct_30m = scaled_realized_sigma_pct(values, 30, horizon_minutes)
    baseline_sigma = realized_sigma_3m_pct_15m or realized_sigma_3m_pct_30m or realized_sigma_3m_pct_5m or 0.0

    if predicted_sigma_3m_pct is None or baseline_sigma <= 0:
        volatility_regime = "neutral"
    elif predicted_sigma_3m_pct > baseline_sigma * 1.15:
        volatility_regime = "expanding"
    elif predicted_sigma_3m_pct < baseline_sigma * 0.85:
        volatility_regime = "contracting"
    else:
        volatility_regime = "stable"

    decision_threshold = max(0.08, (predicted_sigma_3m_pct or baseline_sigma or 0.12) * 0.35)
    final_change_pct = float(final_row["predicted_change_pct"])
    if final_change_pct > decision_threshold:
        signal = "bias_up"
    elif final_change_pct < -decision_threshold:
        signal = "bias_down"
    else:
        signal = "neutral"

    return {
        "generated_at": datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds"),
        "model_version": "2.5",
        "model_family": MODEL_LABEL,
        "source": {
            "exchange": "OKX",
            "endpoint": "public history-candles",
            "inst_id": inst_id,
            "bar": bar,
            "candles_used": int(len(values)),
            "as_of_time": str(candles.iloc[-1]["ts_iso"]),
        },
        "current_price": last_close,
        "horizon_minutes": horizon_minutes,
        "predicted_price_3m": float(final_row["predicted_close"]),
        "predicted_change_abs_3m": float(final_row["predicted_change_abs"]),
        "predicted_change_pct_3m": final_change_pct,
        "predicted_band_pct_3m": final_row["band_pct"],
        "predicted_sigma_3m_pct": predicted_sigma_3m_pct,
        "realized_sigma_3m_pct_5m": realized_sigma_3m_pct_5m,
        "realized_sigma_3m_pct_15m": realized_sigma_3m_pct_15m,
        "realized_sigma_3m_pct_30m": realized_sigma_3m_pct_30m,
        "volatility_regime": volatility_regime,
        "signal": signal,
        "strategy_selection_mode": strategy_selection_mode,
        "strategy_selection_refreshed_at": strategy_refreshed_at,
        "selected_strategy": {
            "context_len": int(selected_strategy["context_len"]),
            "normalize": bool(selected_strategy["normalize"]),
            "backtest_score": float(selected_strategy["score"]),
            "backtest_direction_accuracy": float(selected_strategy["direction_accuracy"]),
            "backtest_mae_pct": float(selected_strategy["mae_pct"]),
            "backtest_sample_size": int(selected_strategy["sample_size"]),
            "checkpoint_repo": checkpoint_repo,
            "selection_mode": strategy_selection_mode,
            "selection_refreshed_at": strategy_refreshed_at,
        },
        "candidate_results": sorted(candidate_results, key=lambda item: float(item["score"]), reverse=True)[:6],
        "predicted_path": path_rows,
        "recent_closes": candles.tail(60)[["ts_ms", "ts_iso", "close"]].to_dict(orient="records"),
        "okx_trade_url": "https://www.okx.com/zh-hans/trade-swap/btc-usd-swap",
        "notes": [
            "This page uses OKX public market data and does not place trades.",
            "The 3-minute estimate is a short-horizon model signal, not a guaranteed fill or execution edge.",
        ],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Predict the next 3-minute BTC move from OKX public candles.")
    parser.add_argument("--inst-id", default=DEFAULT_INST_ID)
    parser.add_argument("--bar", default=DEFAULT_BAR)
    parser.add_argument("--limit", type=int, default=DEFAULT_LIMIT)
    parser.add_argument("--horizon-minutes", type=int, default=DEFAULT_HORIZON_MINUTES)
    parser.add_argument("--backtest-windows", type=int, default=DEFAULT_BACKTEST_WINDOWS)
    parser.add_argument("--strategy-max-age-minutes", type=int, default=DEFAULT_STRATEGY_MAX_AGE_MINUTES)
    parser.add_argument("--force-reselect", action="store_true")
    args = parser.parse_args()

    payload = predict_btc_change(
        inst_id=args.inst_id,
        bar=args.bar,
        limit=max(90, args.limit),
        horizon_minutes=max(1, args.horizon_minutes),
        backtest_windows=max(10, args.backtest_windows),
        strategy_max_age_minutes=max(1, args.strategy_max_age_minutes),
        force_reselect=bool(args.force_reselect),
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
