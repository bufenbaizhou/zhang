import argparse
import json
from pathlib import Path

import pandas as pd
import timesfm

from cycle_shared import ensure_config, load_history


DEFAULT_CHECKPOINT = "google/timesfm-1.0-200m-pytorch"

def build_model(horizon_len: int, checkpoint_repo: str) -> timesfm.TimesFm:
    hparams = timesfm.TimesFmHparams(
        backend="cpu",
        per_core_batch_size=32,
        horizon_len=horizon_len,
    )
    checkpoint = timesfm.TimesFmCheckpoint(huggingface_repo_id=checkpoint_repo)
    return timesfm.TimesFm(hparams=hparams, checkpoint=checkpoint)


def forecast_next_days(
    ticker: str,
    period: str,
    context_len: int,
    horizon_len: int,
    checkpoint_repo: str,
) -> dict:
    config = ensure_config()
    history = load_history(
        ticker=ticker,
        period=period,
        source=config.get("history_data_source"),
    )
    history["unique_id"] = ticker
    history["ds"] = pd.to_datetime(history["ds"]).dt.tz_localize(None)
    history = history.dropna().sort_values("ds")

    model = build_model(horizon_len=horizon_len, checkpoint_repo=checkpoint_repo)
    forecast_df = model.forecast_on_df(
        inputs=history,
        freq="B",
        forecast_context_len=context_len,
        value_name="values",
        model_name="timesfm",
        normalize=True,
        verbose=True,
    )

    last_row = history.iloc[-1]
    output = forecast_df.copy()
    output["ds"] = pd.to_datetime(output["ds"]).dt.strftime("%Y-%m-%d")

    first_pred = output.iloc[0]
    prediction = float(first_pred["timesfm"])
    last_close = float(last_row["values"])

    return {
        "ticker": ticker,
        "checkpoint_repo": checkpoint_repo,
        "history_rows": int(len(history)),
        "history_start": history["ds"].min().strftime("%Y-%m-%d"),
        "history_end": history["ds"].max().strftime("%Y-%m-%d"),
        "last_close": last_close,
        "forecast_start": str(first_pred["ds"]),
        "forecast_close": prediction,
        "predicted_change_abs": prediction - last_close,
        "predicted_change_pct": (prediction / last_close - 1.0) * 100.0,
        "forecast_table": output.to_dict(orient="records"),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Forecast a stock with TimesFM.")
    parser.add_argument("--ticker", default="600722.SS", help="A-share ticker like 600722.SS or 300750.SZ")
    parser.add_argument("--period", default="2y", help="History window like 6mo, 1y, 2y or max")
    parser.add_argument("--context-len", type=int, default=256)
    parser.add_argument("--horizon-len", type=int, default=5)
    parser.add_argument("--checkpoint-repo", default=DEFAULT_CHECKPOINT)
    parser.add_argument(
        "--output",
        default=str(Path(__file__).resolve().parent / "outputs" / "forecast.json"),
    )
    args = parser.parse_args()

    result = forecast_next_days(
        ticker=args.ticker,
        period=args.period,
        context_len=args.context_len,
        horizon_len=args.horizon_len,
        checkpoint_repo=args.checkpoint_repo,
    )

    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

    print(json.dumps(result, ensure_ascii=False, indent=2))
    print(f"\nSaved forecast to: {output_path}")


if __name__ == "__main__":
    main()
