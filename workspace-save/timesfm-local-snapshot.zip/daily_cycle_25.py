from __future__ import annotations

import argparse
import json
import os
import traceback
import uuid
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd
import timesfm

from cycle_shared import (
    CALENDAR,
    SHANGHAI_TZ,
    V25_DASHBOARD_PATH,
    V25_PREDICTIONS_PATH,
    V25_RUNS_PATH,
    V25_STATUS_PATH,
    config_payload,
    ensure_config,
    load_history,
    normalize_ticker,
    read_json,
    resolve_active_watchlist,
    write_json,
)


MODEL_LABEL = "TimesFM 2.5"
HIT_ERROR_THRESHOLD_PCT = 0.3
BASE_MODEL: timesfm.TimesFM_2p5_200M_torch | None = None
CURRENT_COMPILE_KEY: tuple[int, int, bool] | None = None


def update_daily_cycle_status(**updates: Any) -> dict[str, Any]:
    current = read_json(V25_STATUS_PATH, {})
    next_payload = {**current, **updates}
    write_json(V25_STATUS_PATH, next_payload)
    return next_payload


def build_cycle_conclusion(dashboard: dict[str, Any], evaluated_count: int, refreshed_ticker_count: int) -> str:
    metrics = dashboard.get("metrics", {})
    return (
        f"本轮刷新 {refreshed_ticker_count} 只股票，生成 {dashboard.get('prediction_count', 0)} 条次日预测，"
        f"确认 {evaluated_count} 条历史记录；最近 20 次命中率 "
        f"{float(metrics.get('recent_direction_accuracy', 0.0)) * 100.0:.2f}% ，"
        f"平均误差 {float(metrics.get('recent_avg_abs_error_pct', 0.0)):.2f}% ，"
        f"待确认 {int(metrics.get('pending_next_day_count', 0))} 条。"
    )


def get_model(checkpoint_repo: str) -> timesfm.TimesFM_2p5_200M_torch:
    global BASE_MODEL
    if BASE_MODEL is None:
        BASE_MODEL = timesfm.TimesFM_2p5_200M_torch.from_pretrained(checkpoint_repo)
    return BASE_MODEL


def get_compiled_model(checkpoint_repo: str, context_len: int, horizon_len: int, normalize: bool):
    global CURRENT_COMPILE_KEY
    model = get_model(checkpoint_repo)
    compile_key = (context_len, horizon_len, normalize)
    if CURRENT_COMPILE_KEY != compile_key:
        model.compile(
            timesfm.ForecastConfig(
                max_context=context_len,
                max_horizon=horizon_len,
                normalize_inputs=normalize,
                use_continuous_quantile_head=True,
                force_flip_invariance=True,
                infer_is_positive=True,
                fix_quantile_crossing=True,
            )
        )
        CURRENT_COMPILE_KEY = compile_key
    return model


def sign_of(value: float, flat_threshold: float = 1e-8) -> int:
    if abs(value) <= flat_threshold:
        return 0
    return 1 if value > 0 else -1


def is_hit(abs_error_pct: float | None) -> bool:
    if abs_error_pct is None:
        return False
    return float(abs_error_pct) <= HIT_ERROR_THRESHOLD_PCT


def quantile_value(full_forecast: np.ndarray, step_index: int, q: float) -> float | None:
    index_map = {0.1: 1, 0.2: 2, 0.3: 3, 0.4: 4, 0.5: 5, 0.6: 6, 0.7: 7, 0.8: 8, 0.9: 9}
    index = index_map.get(q)
    if index is None or full_forecast.shape[-1] <= index:
        return None
    return float(full_forecast[0, step_index, index])


def score_candidate(
    checkpoint_repo: str,
    values: np.ndarray,
    dates: list[str],
    context_len: int,
    normalize: bool,
    backtest_days: int,
    horizon_len: int,
) -> dict[str, Any]:
    usable_days = min(backtest_days, max(len(values) - 40, 0))
    if usable_days <= 0:
        return {
            "score": float("-inf"),
            "direction_accuracy": 0.0,
            "mae_pct": float("inf"),
            "sample_size": 0,
            "normalize": normalize,
            "context_len": context_len,
        }

    model = get_compiled_model(
        checkpoint_repo=checkpoint_repo,
        context_len=context_len,
        horizon_len=max(1, horizon_len),
        normalize=normalize,
    )

    hits = 0
    abs_errors: list[float] = []
    for offset in range(usable_days, 0, -1):
        history = values[:-offset]
        actual_close = float(values[-offset])
        prev_close = float(history[-1])
        point_forecast, _ = model.forecast(horizon=1, inputs=[history])
        predicted_close = float(point_forecast[0][0])
        hits += int(sign_of(predicted_close - prev_close) == sign_of(actual_close - prev_close))
        abs_errors.append(abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0)

    sample_size = len(abs_errors)
    direction_accuracy = hits / sample_size if sample_size else 0.0
    mae_pct = sum(abs_errors) / sample_size if sample_size else float("inf")
    return {
        "score": direction_accuracy * 100.0 - mae_pct * 2.0,
        "direction_accuracy": direction_accuracy,
        "mae_pct": mae_pct,
        "sample_size": sample_size,
        "normalize": normalize,
        "context_len": context_len,
    }


def next_sessions(last_session: str, count: int) -> list[str]:
    anchor = CALENDAR.date_to_session(pd.Timestamp(last_session))
    return [
        pd.Timestamp(session).strftime("%Y-%m-%d")
        for session in CALENDAR.sessions_window(anchor, count + 1)[1:]
    ]


def generate_for_ticker(
    watch_item: dict[str, Any],
    config: dict[str, Any],
    history: pd.DataFrame,
    generated_at: str,
) -> list[dict[str, Any]]:
    values = history["values"].to_numpy(dtype=float)
    dates = history["ds"].tolist()
    as_of_date = dates[-1]
    checkpoint_repo = str(config["v25_checkpoint"])
    horizon_len = int(config["horizon_len"])

    candidate_results: list[dict[str, Any]] = []
    selected_strategy: dict[str, Any] | None = None
    for context_len in config["candidate_context_lengths_v25"]:
        for normalize in config["candidate_normalize"]:
            result = score_candidate(
                checkpoint_repo=checkpoint_repo,
                values=values,
                dates=dates,
                context_len=int(context_len),
                normalize=bool(normalize),
                backtest_days=int(config["backtest_days"]),
                horizon_len=horizon_len,
            )
            result["checkpoint_repo"] = checkpoint_repo
            candidate_results.append(result)
            if selected_strategy is None or float(result["score"]) > float(selected_strategy["score"]):
                selected_strategy = result

    if selected_strategy is None:
        raise RuntimeError(f"Could not select a TimesFM 2.5 strategy for {watch_item['ticker']}.")

    model = get_compiled_model(
        checkpoint_repo=checkpoint_repo,
        context_len=int(selected_strategy["context_len"]),
        horizon_len=horizon_len,
        normalize=bool(selected_strategy["normalize"]),
    )
    point_forecast, quantile_forecast = model.forecast(horizon=horizon_len, inputs=[values])
    future_dates = next_sessions(as_of_date, horizon_len)
    last_close = float(values[-1])
    run_id = uuid.uuid4().hex

    rows: list[dict[str, Any]] = []
    for step_index, target_date in enumerate(future_dates):
        predicted_close = float(point_forecast[0][step_index])
        predicted_change_abs = predicted_close - last_close
        predicted_change_pct = predicted_change_abs / max(abs(last_close), 1e-8) * 100.0
        rows.append(
            {
                "id": f"v25|{watch_item['ticker']}|{as_of_date}|{target_date}|{step_index + 1}",
                "run_id": run_id,
                "model_version": "2.5",
                "model_family": MODEL_LABEL,
                "ticker": watch_item["ticker"],
                "name": watch_item["name"],
                "source_pool": watch_item["source_pool"],
                "source_tags": watch_item["source_tags"],
                "as_of_date": as_of_date,
                "target_date": target_date,
                "horizon_step": step_index + 1,
                "generated_at": generated_at,
                "last_close": last_close,
                "predicted_close": predicted_close,
                "predicted_change_abs": predicted_change_abs,
                "predicted_change_pct": predicted_change_pct,
                "q20_close": quantile_value(quantile_forecast, step_index, 0.2),
                "q50_close": quantile_value(quantile_forecast, step_index, 0.5),
                "q80_close": quantile_value(quantile_forecast, step_index, 0.8),
                "checkpoint_repo": checkpoint_repo,
                "context_len": int(selected_strategy["context_len"]),
                "normalize": bool(selected_strategy["normalize"]),
                "backtest_score": float(selected_strategy["score"]),
                "backtest_direction_accuracy": float(selected_strategy["direction_accuracy"]),
                "backtest_mae_pct": float(selected_strategy["mae_pct"]),
                "backtest_sample_size": int(selected_strategy["sample_size"]),
                "candidate_results": sorted(candidate_results, key=lambda item: float(item["score"]), reverse=True)[:5],
                "status": "pending",
                "actual_close": None,
                "actual_change_abs": None,
                "actual_change_pct": None,
                "abs_error_pct": None,
                "direction_hit": None,
                "evaluated_at": None,
            }
        )
    return rows


def evaluate_predictions(
    predictions: list[dict[str, Any]],
    history_map: dict[str, dict[str, float]],
    generated_at: str,
) -> int:
    updated = 0
    for record in predictions:
        if record.get("status") == "evaluated":
            continue
        actual_close = history_map.get(str(record["ticker"]), {}).get(str(record["target_date"]))
        if actual_close is None:
            continue
        last_close = float(record["last_close"])
        predicted_close = float(record["predicted_close"])
        actual_change_abs = actual_close - last_close
        record["actual_close"] = actual_close
        record["actual_change_abs"] = actual_change_abs
        record["actual_change_pct"] = actual_change_abs / max(abs(last_close), 1e-8) * 100.0
        abs_error_pct = abs(predicted_close - actual_close) / max(abs(actual_close), 1e-8) * 100.0
        record["abs_error_pct"] = abs_error_pct
        record["direction_hit"] = is_hit(abs_error_pct)
        record["status"] = "evaluated"
        record["evaluated_at"] = generated_at
        updated += 1
    return updated


def normalize_hit_flags(predictions: list[dict[str, Any]]) -> None:
    for record in predictions:
        if record.get("status") != "evaluated":
            continue
        abs_error_pct = record.get("abs_error_pct")
        if abs_error_pct is None:
            continue
        record["direction_hit"] = is_hit(float(abs_error_pct))


def latest_next_day_predictions(predictions: list[dict[str, Any]], active_watchlist: list[dict[str, Any]]) -> list[dict[str, Any]]:
    latest_by_ticker: dict[str, dict[str, Any]] = {}
    for record in sorted(
        [item for item in predictions if int(item["horizon_step"]) == 1],
        key=lambda item: (str(item["as_of_date"]), str(item["generated_at"])),
        reverse=True,
    ):
        ticker = str(record["ticker"])
        if ticker not in latest_by_ticker:
            latest_by_ticker[ticker] = record
    watch_order = {item["ticker"]: index for index, item in enumerate(active_watchlist)}
    return sorted(latest_by_ticker.values(), key=lambda item: watch_order.get(str(item["ticker"]), 9999))


def recent_confirmations(predictions: list[dict[str, Any]], limit: int = 30) -> list[dict[str, Any]]:
    confirmed = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") == "evaluated"
    ]
    return sorted(confirmed, key=lambda item: str(item["target_date"]), reverse=True)[:limit]


def compute_metrics(predictions: list[dict[str, Any]]) -> dict[str, Any]:
    confirmed = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") == "evaluated"
    ]
    recent = sorted(confirmed, key=lambda item: str(item["target_date"]), reverse=True)[:20]
    pending = [
        item for item in predictions if int(item["horizon_step"]) == 1 and item.get("status") != "evaluated"
    ]
    direction_accuracy = 0.0
    avg_abs_error_pct = 0.0
    if recent:
        direction_accuracy = sum(1 for item in recent if item.get("direction_hit")) / len(recent)
        avg_abs_error_pct = sum(float(item["abs_error_pct"]) for item in recent) / len(recent)
    return {
        "confirmed_count": len(confirmed),
        "recent_confirmed_count": len(recent),
        "recent_direction_accuracy": direction_accuracy,
        "recent_avg_abs_error_pct": avg_abs_error_pct,
        "pending_next_day_count": len(pending),
    }


def build_dashboard(
    config: dict[str, Any],
    predictions: list[dict[str, Any]],
    active_watchlist: list[dict[str, Any]],
    generated_at: str,
) -> dict[str, Any]:
    next_day = latest_next_day_predictions(predictions, active_watchlist)
    return {
        "generated_at": generated_at,
        "model_version": "2.5",
        "model_family": MODEL_LABEL,
        "config": config_payload(config, active_watchlist),
        "metrics": compute_metrics(predictions),
        "bullish_count": sum(1 for item in next_day if float(item["predicted_change_pct"]) > 0),
        "bearish_count": sum(1 for item in next_day if float(item["predicted_change_pct"]) < 0),
        "next_day_predictions": next_day,
        "recent_confirmations": recent_confirmations(predictions),
        "prediction_count": len(predictions),
    }


def run_daily_cycle(filter_tickers: set[str] | None = None) -> dict[str, Any]:
    generated_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
    existing_dashboard = read_json(V25_DASHBOARD_PATH, {})
    update_daily_cycle_status(
        status="running",
        pid=os.getpid(),
        started_at=generated_at,
        finished_at=None,
        stage="running",
        stage_label="正在运行 TimesFM 2.5 日更和确认",
        mode="filtered" if filter_tickers else "full",
        tickers=sorted(filter_tickers) if filter_tickers else [],
        error=None,
        conclusion=None,
        summary=None,
        last_generated_at=existing_dashboard.get("generated_at"),
    )

    try:
        config = ensure_config()
        active_watchlist = resolve_active_watchlist(config)
        if filter_tickers is not None:
            active_watchlist = [item for item in active_watchlist if item["ticker"] in filter_tickers]

        predictions: list[dict[str, Any]] = read_json(V25_PREDICTIONS_PATH, [])
        runs: list[dict[str, Any]] = read_json(V25_RUNS_PATH, [])
        histories: dict[str, pd.DataFrame] = {}
        history_map: dict[str, dict[str, float]] = {}

        normalize_hit_flags(predictions)

        for watch_item in active_watchlist:
            history = load_history(
                watch_item["ticker"],
                config["history_period"],
                source=config.get("history_data_source"),
            )
            histories[watch_item["ticker"]] = history
            history_map[watch_item["ticker"]] = {
                str(row["ds"]): float(row["values"]) for _, row in history.iterrows()
            }

        evaluated_count = evaluate_predictions(predictions, history_map, generated_at)

        for watch_item in active_watchlist:
            as_of_date = str(histories[watch_item["ticker"]].iloc[-1]["ds"])
            predictions = [
                item
                for item in predictions
                if not (
                    str(item["ticker"]) == watch_item["ticker"]
                    and str(item["as_of_date"]) == as_of_date
                    and str(item.get("model_version")) == "2.5"
                )
            ]
            predictions.extend(generate_for_ticker(watch_item, config, histories[watch_item["ticker"]], generated_at))

        predictions = sorted(
            predictions,
            key=lambda item: (str(item["as_of_date"]), int(item["horizon_step"]), str(item["ticker"])),
        )
        dashboard = build_dashboard(config, predictions, active_watchlist, generated_at)
        runs.append(
            {
                "generated_at": generated_at,
                "model_version": "2.5",
                "tickers": [item["ticker"] for item in active_watchlist],
                "evaluated_count": evaluated_count,
                "prediction_count": len([item for item in predictions if item["generated_at"] == generated_at]),
                "metrics": dashboard["metrics"],
            }
        )

        write_json(V25_PREDICTIONS_PATH, predictions)
        write_json(V25_DASHBOARD_PATH, dashboard)
        write_json(V25_RUNS_PATH, runs[-100:])

        finished_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
        summary = {
            "generated_at": dashboard.get("generated_at"),
            "refreshed_ticker_count": len(active_watchlist),
            "prediction_count": dashboard.get("prediction_count", 0),
            "evaluated_count": evaluated_count,
            "metrics": dashboard.get("metrics", {}),
        }
        update_daily_cycle_status(
            status="succeeded",
            pid=os.getpid(),
            started_at=generated_at,
            finished_at=finished_at,
            stage="completed",
            stage_label="TimesFM 2.5 日更完成",
            mode="filtered" if filter_tickers else "full",
            tickers=[item["ticker"] for item in active_watchlist],
            error=None,
            summary=summary,
            conclusion=build_cycle_conclusion(dashboard, evaluated_count, len(active_watchlist)),
            last_generated_at=dashboard.get("generated_at"),
        )
        return dashboard
    except Exception as exc:
        finished_at = datetime.now(SHANGHAI_TZ).isoformat(timespec="seconds")
        update_daily_cycle_status(
            status="failed",
            pid=os.getpid(),
            started_at=generated_at,
            finished_at=finished_at,
            stage="failed",
            stage_label="TimesFM 2.5 日更失败",
            mode="filtered" if filter_tickers else "full",
            tickers=sorted(filter_tickers) if filter_tickers else [],
            error={
                "message": str(exc),
                "traceback": traceback.format_exc(limit=12),
            },
            conclusion=None,
            summary=None,
            last_generated_at=existing_dashboard.get("generated_at"),
        )
        raise


def main() -> None:
    parser = argparse.ArgumentParser(description="Run TimesFM 2.5 A-share daily cycle.")
    parser.add_argument("--tickers", default="", help="Optional comma-separated ticker filter")
    args = parser.parse_args()
    filter_tickers = None
    if args.tickers.strip():
        filter_tickers = {normalize_ticker(item) for item in args.tickers.split(",") if item.strip()}
    print(json.dumps(run_daily_cycle(filter_tickers=filter_tickers), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
