# TimesFM Local Forecast

This folder contains the local A-share forecasting pipeline used by the dashboard in `Toonflow-app`.

What is deployed here:

- `TimesFM 2.5` as the main local model
- optional `TimesFM 1.0` as a benchmark baseline
- A-share daily history pulled from Eastmoney-compatible market endpoints
- next-day confirmation that checks actual close prices on the following run
- rolling model selection that blends same-day backtest with confirmed live results

Local environments on this machine:

- `timesfm25`: TimesFM 2.5 runner
- `timesfm311`: TimesFM 1.0 baseline runner

Recreate the baseline environment later with:

```powershell
conda env create -f C:\Users\84922\Desktop\codeX\timesfm_local\environment.yml
```

Run a single-stock forecast:

```powershell
conda run -n timesfm311 python C:\Users\84922\Desktop\codeX\timesfm_local\predict_stock_timesfm.py --ticker 600519.SS
```

Run the TimesFM 2.5 daily A-share cycle:

```powershell
C:\Users\84922\anaconda3\envs\timesfm25\python.exe C:\Users\84922\Desktop\codeX\timesfm_local\daily_cycle_25.py
```

Run the full local batch pipeline and rebuild the combined dashboard:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\84922\Desktop\codeX\Toonflow-app\scripts\run-timesfm-daily.ps1
```

Install the weekday scheduled task at 16:10 local time:

```powershell
powershell -ExecutionPolicy Bypass -File C:\Users\84922\Desktop\codeX\Toonflow-app\scripts\install-timesfm-daily-task.ps1
```

Open the local dashboard after starting Toonflow:

```text
http://127.0.0.1:60000/other/timesfmDashboard
```

Quick start next time after boot on this machine:

```powershell
C:\Users\84922\Desktop\codeX\start-timesfm-dashboard.cmd
```
