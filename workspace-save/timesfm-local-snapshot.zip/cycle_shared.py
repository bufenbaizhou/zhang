from __future__ import annotations

import json
import os
import random
import socket
import ssl
import time
from http.client import IncompleteRead, RemoteDisconnected
from datetime import date, timedelta
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

import exchange_calendars as xcals
import pandas as pd


SHANGHAI_TZ = ZoneInfo("Asia/Shanghai")
CALENDAR = xcals.get_calendar("XSHG")
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CONFIG_PATH = DATA_DIR / "config.json"
V1_PREDICTIONS_PATH = DATA_DIR / "predictions.json"
V1_DASHBOARD_PATH = DATA_DIR / "dashboard.json"
V1_RUNS_PATH = DATA_DIR / "runs.json"
V25_PREDICTIONS_PATH = DATA_DIR / "predictions_25.json"
V25_DASHBOARD_PATH = DATA_DIR / "dashboard_25.json"
V25_RUNS_PATH = DATA_DIR / "runs_25.json"
V25_STATUS_PATH = DATA_DIR / "daily_cycle_status_25.json"
COMBINED_DASHBOARD_PATH = DATA_DIR / "dashboard_combined.json"
STRATEGY_SELECTIONS_PATH = DATA_DIR / "strategy_selections.json"
CURRENT_CONFIG_VERSION = 4
EASTMONEY_HISTORY_URL = "https://push2his.eastmoney.com/api/qt/stock/kline/get"
TENCENT_HISTORY_URL = "https://web.ifzq.gtimg.cn/appstock/app/fqkline/get"
SOHU_HISTORY_URL = "https://q.stock.sohu.com/hisHq"
SUPPORTED_HISTORY_SOURCES = {"auto", "eastmoney", "sohu", "tencent"}
DEFAULT_HTTP_HEADERS = {
    "Accept": "application/json,text/plain,*/*",
    "Accept-Encoding": "identity",
    "Cache-Control": "no-cache",
    "Connection": "close",
    "Pragma": "no-cache",
    "Referer": "https://quote.eastmoney.com/",
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/135.0.0.0 Safari/537.36",
}


def env_float(name: str, default: float) -> float:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return float(raw)
    except (TypeError, ValueError):
        return default


def env_int(name: str, default: int) -> int:
    raw = os.getenv(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except (TypeError, ValueError):
        return default


DEFAULT_FETCH_TIMEOUT_SECONDS = env_float("TIMESFM_HTTP_TIMEOUT", 12.0)
DEFAULT_FETCH_RETRIES = max(1, env_int("TIMESFM_HTTP_RETRIES", 3))
DEFAULT_FETCH_RETRY_BACKOFF_SECONDS = env_float("TIMESFM_HTTP_RETRY_BACKOFF", 1.5)
DEFAULT_FETCH_RETRY_BACKOFF_MAX_SECONDS = env_float("TIMESFM_HTTP_RETRY_BACKOFF_MAX", 10.0)
DEFAULT_FETCH_RETRY_JITTER_SECONDS = env_float("TIMESFM_HTTP_RETRY_JITTER", 0.35)

THEME_PRESETS: dict[str, list[dict[str, str]]] = {
    "化工": [
        {"ticker": "600722.SS", "name": "金牛化工"},
        {"ticker": "600309.SS", "name": "万华化学"},
        {"ticker": "002648.SZ", "name": "卫星化学"},
        {"ticker": "600426.SS", "name": "华鲁恒升"},
        {"ticker": "600486.SS", "name": "扬农化工"},
    ],
    "银行": [
        {"ticker": "600036.SS", "name": "招商银行"},
        {"ticker": "000001.SZ", "name": "平安银行"},
        {"ticker": "601166.SS", "name": "兴业银行"},
        {"ticker": "002142.SZ", "name": "宁波银行"},
        {"ticker": "600919.SS", "name": "江苏银行"},
    ],
    "煤炭": [
        {"ticker": "601088.SS", "name": "中国神华"},
        {"ticker": "601225.SS", "name": "陕西煤业"},
        {"ticker": "600188.SS", "name": "兖矿能源"},
        {"ticker": "600546.SS", "name": "山煤国际"},
        {"ticker": "601001.SS", "name": "晋控煤业"},
    ],
    "有色": [
        {"ticker": "601899.SS", "name": "紫金矿业"},
        {"ticker": "603799.SS", "name": "华友钴业"},
        {"ticker": "603993.SS", "name": "洛阳钼业"},
        {"ticker": "600111.SS", "name": "北方稀土"},
    ],
}

DEFAULT_ANALYST_WATCHLIST: list[dict[str, str]] = [
    {"ticker": "600722.SS", "name": "金牛化工"},
    {"ticker": "600519.SS", "name": "贵州茅台"},
    {"ticker": "300750.SZ", "name": "宁德时代"},
    {"ticker": "002594.SZ", "name": "比亚迪"},
    {"ticker": "601318.SS", "name": "中国平安"},
    {"ticker": "601899.SS", "name": "紫金矿业"},
    {"ticker": "600036.SS", "name": "招商银行"},
    {"ticker": "000001.SZ", "name": "平安银行"},
]

DEFAULT_CONFIG: dict[str, Any] = {
    "config_version": CURRENT_CONFIG_VERSION,
    "deployment_mode": "locked",
    "locked_model_version": "2.5",
    "history_period": "2y",
    "history_data_source": "auto",
    "horizon_len": 5,
    "backtest_days": 20,
    "candidate_context_lengths_v1": [128, 256, 512],
    "candidate_context_lengths_v25": [128, 256, 512, 1024, 2048],
    "candidate_normalize": [True, False],
    "v1_checkpoint": "google/timesfm-1.0-200m-pytorch",
    "v25_checkpoint": "google/timesfm-2.5-200m-pytorch",
    "analyst_watchlist": DEFAULT_ANALYST_WATCHLIST,
    "custom_watchlist": [],
    "custom_themes": [],
}


def read_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def normalize_ticker(raw: str) -> str:
    ticker = raw.upper().strip()
    if ticker.endswith((".SS", ".SZ", ".BJ")):
        return ticker
    digits = "".join(ch for ch in ticker if ch.isdigit())
    if len(digits) != 6:
        return ticker
    if digits.startswith(("4", "8")) or digits.startswith("92"):
        return f"{digits}.BJ"
    if digits.startswith(("5", "6", "9")):
        return f"{digits}.SS"
    return f"{digits}.SZ"


def is_supported_ticker(raw: str) -> bool:
    ticker = str(raw or "").strip().upper()
    if len(ticker) != 9:
        return False
    symbol, suffix = ticker.split(".", 1) if "." in ticker else ("", "")
    return len(symbol) == 6 and symbol.isdigit() and suffix in {"SS", "SZ", "BJ"}


def normalize_watchlist(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    normalized: list[dict[str, str]] = []
    seen: set[str] = set()
    for item in items:
        ticker = normalize_ticker(str(item.get("ticker", "")).strip())
        name = str(item.get("name", "")).strip() or ticker
        if not ticker or not is_supported_ticker(ticker) or ticker in seen:
            continue
        normalized.append({"ticker": ticker, "name": name})
        seen.add(ticker)
    return normalized


def normalize_themes(themes: list[Any]) -> list[str]:
    output: list[str] = []
    seen: set[str] = set()
    for item in themes:
        theme = str(item).strip()
        if not theme or theme in seen:
            continue
        output.append(theme)
        seen.add(theme)
    return output


def ensure_config() -> dict[str, Any]:
    current = read_json(CONFIG_PATH, {})
    merged = {**DEFAULT_CONFIG, **current}
    config_version = int(current.get("config_version", 0))
    if config_version < CURRENT_CONFIG_VERSION:
        if current.get("backtest_days") in (None, 5):
            merged["backtest_days"] = DEFAULT_CONFIG["backtest_days"]
        if current.get("candidate_context_lengths_v25") in (None, [128, 256, 512, 1024]):
            merged["candidate_context_lengths_v25"] = DEFAULT_CONFIG["candidate_context_lengths_v25"]
        merged["deployment_mode"] = "locked"
        merged["locked_model_version"] = "2.5"
        merged["history_data_source"] = str(current.get("history_data_source") or DEFAULT_CONFIG["history_data_source"])
    merged["config_version"] = CURRENT_CONFIG_VERSION
    if current.get("watchlist") and not current.get("analyst_watchlist"):
        merged["analyst_watchlist"] = current["watchlist"]
    merged["analyst_watchlist"] = normalize_watchlist(merged.get("analyst_watchlist", []))
    merged["custom_watchlist"] = normalize_watchlist(merged.get("custom_watchlist", []))
    merged["custom_themes"] = normalize_themes(merged.get("custom_themes", []))
    merged["history_data_source"] = normalize_history_source(merged.get("history_data_source"))
    write_json(CONFIG_PATH, merged)
    return merged


def expand_custom_theme_watchlist(theme_names: list[str]) -> list[dict[str, str]]:
    expanded: list[dict[str, str]] = []
    for theme in theme_names:
        expanded.extend(THEME_PRESETS.get(theme, []))
    return normalize_watchlist(expanded)


def resolve_active_watchlist(config: dict[str, Any]) -> list[dict[str, Any]]:
    merged: dict[str, dict[str, Any]] = {}

    def upsert(item: dict[str, str], tag: str, pool: str) -> None:
        ticker = normalize_ticker(item["ticker"])
        entry = merged.get(
            ticker,
            {
                "ticker": ticker,
                "name": item["name"],
                "source_tags": [],
                "is_analyst": False,
                "is_custom": False,
            },
        )
        if not entry["name"] or entry["name"] == ticker:
            entry["name"] = item["name"]
        if tag not in entry["source_tags"]:
            entry["source_tags"].append(tag)
        if pool == "analysis":
            entry["is_analyst"] = True
        if pool == "custom":
            entry["is_custom"] = True
        merged[ticker] = entry

    for item in normalize_watchlist(config.get("analyst_watchlist", [])):
        upsert(item, "分析池", "analysis")

    for theme in normalize_themes(config.get("custom_themes", [])):
        for item in THEME_PRESETS.get(theme, []):
            upsert(item, f"主题:{theme}", "custom")

    for item in normalize_watchlist(config.get("custom_watchlist", [])):
        upsert(item, "自定义池", "custom")

    active: list[dict[str, Any]] = []
    for value in merged.values():
        if value["is_analyst"] and value["is_custom"]:
            source_pool = "hybrid"
        elif value["is_analyst"]:
            source_pool = "analysis"
        else:
            source_pool = "custom"
        active.append(
            {
                "ticker": value["ticker"],
                "name": value["name"],
                "source_tags": value["source_tags"],
                "source_pool": source_pool,
            }
        )

    order = {item["ticker"]: index for index, item in enumerate(normalize_watchlist(config.get("analyst_watchlist", [])))}
    custom_offset = len(order)
    for item in normalize_watchlist(config.get("custom_watchlist", [])):
        if item["ticker"] not in order:
            order[item["ticker"]] = custom_offset
            custom_offset += 1

    return sorted(active, key=lambda item: order.get(item["ticker"], 9999))


def config_payload(config: dict[str, Any], resolved_watchlist: list[dict[str, Any]]) -> dict[str, Any]:
    return {
        "config_version": config["config_version"],
        "deployment_mode": config["deployment_mode"],
        "locked_model_version": config["locked_model_version"],
        "history_period": config["history_period"],
        "history_data_source": config.get("history_data_source", "auto"),
        "horizon_len": config["horizon_len"],
        "backtest_days": config["backtest_days"],
        "candidate_context_lengths_v1": config["candidate_context_lengths_v1"],
        "candidate_context_lengths_v25": config["candidate_context_lengths_v25"],
        "candidate_normalize": config["candidate_normalize"],
        "v1_checkpoint": config["v1_checkpoint"],
        "v25_checkpoint": config["v25_checkpoint"],
        "analyst_watchlist": config["analyst_watchlist"],
        "custom_watchlist": config["custom_watchlist"],
        "custom_themes": config["custom_themes"],
        "available_history_data_sources": sorted(SUPPORTED_HISTORY_SOURCES),
        "available_themes": sorted(THEME_PRESETS),
        "resolved_watchlist": resolved_watchlist,
    }


def period_to_start_date(period: str) -> date:
    normalized = str(period).strip().lower()
    today = date.today()
    if normalized == "max":
        return date(1990, 1, 1)
    if normalized.endswith("y") and normalized[:-1].isdigit():
        return today - timedelta(days=int(normalized[:-1]) * 365)
    if normalized.endswith("mo") and normalized[:-2].isdigit():
        return today - timedelta(days=int(normalized[:-2]) * 31)
    if normalized.endswith("m") and normalized[:-1].isdigit():
        return today - timedelta(days=int(normalized[:-1]) * 31)
    if normalized.endswith("d") and normalized[:-1].isdigit():
        return today - timedelta(days=int(normalized[:-1]))
    return today - timedelta(days=730)


def eastmoney_secid(ticker: str) -> str:
    normalized = normalize_ticker(ticker)
    digits = "".join(ch for ch in normalized if ch.isdigit())
    if len(digits) != 6:
        raise RuntimeError(f"Unsupported China-stock ticker: {ticker}")
    if normalized.endswith(".BJ"):
        market = "0"
    else:
        market = "1" if normalized.endswith(".SS") else "0"
    return f"{market}.{digits}"


def normalize_history_source(raw: Any) -> str:
    candidate = str(raw or "").strip().lower()
    if candidate in SUPPORTED_HISTORY_SOURCES:
        return candidate
    return "auto"


def tencent_symbol(ticker: str) -> str:
    normalized = normalize_ticker(ticker)
    digits = "".join(ch for ch in normalized if ch.isdigit())
    if len(digits) != 6:
        raise RuntimeError(f"Unsupported China-stock ticker: {ticker}")
    if normalized.endswith(".SS"):
        prefix = "sh"
    elif normalized.endswith(".BJ"):
        prefix = "bj"
    else:
        prefix = "sz"
    return f"{prefix}{digits}"


def sohu_symbol(ticker: str) -> str:
    normalized = normalize_ticker(ticker)
    digits = "".join(ch for ch in normalized if ch.isdigit())
    if len(digits) != 6:
        raise RuntimeError(f"Unsupported China-stock ticker: {ticker}")
    return f"cn_{digits}"


def history_source_order(ticker: str, source: str | None) -> list[str]:
    normalized_source = normalize_history_source(source or os.getenv("TIMESFM_HISTORY_SOURCE"))
    if normalized_source != "auto":
        return [normalized_source]
    normalized_ticker = normalize_ticker(ticker)
    if normalized_ticker.endswith(".BJ"):
        return ["sohu", "tencent", "eastmoney"]
    return ["tencent", "sohu", "eastmoney"]


def fetch_text(
    url: str,
    params: dict[str, Any],
    retries: int | None = None,
    timeout: float | None = None,
) -> str:
    encoded = urlencode({key: value for key, value in params.items() if value is not None})
    last_error: Exception | None = None
    attempts = max(1, int(retries if retries is not None else DEFAULT_FETCH_RETRIES))
    effective_timeout = max(5.0, float(timeout if timeout is not None else DEFAULT_FETCH_TIMEOUT_SECONDS))
    backoff_seconds = max(0.5, float(DEFAULT_FETCH_RETRY_BACKOFF_SECONDS))
    for attempt in range(attempts):
        request = Request(f"{url}?{encoded}", headers=DEFAULT_HTTP_HEADERS)
        try:
            with urlopen(request, timeout=effective_timeout) as response:
                payload = response.read()
            try:
                return payload.decode("utf-8")
            except UnicodeDecodeError:
                return payload.decode("gb18030")
        except Exception as exc:  # pragma: no cover - network failures are environment-specific
            last_error = exc
            if isinstance(exc, HTTPError) and exc.code not in (408, 425, 429) and exc.code < 500:
                break
            if attempt == attempts - 1:
                break
            sleep_seconds = min(
                DEFAULT_FETCH_RETRY_BACKOFF_MAX_SECONDS,
                backoff_seconds * (2**attempt),
            ) + random.uniform(0.0, max(0.0, DEFAULT_FETCH_RETRY_JITTER_SECONDS))

            if isinstance(
                exc,
                (
                    TimeoutError,
                    socket.timeout,
                    ConnectionError,
                    ConnectionResetError,
                    ConnectionAbortedError,
                    ConnectionRefusedError,
                    BrokenPipeError,
                    IncompleteRead,
                    RemoteDisconnected,
                    URLError,
                    ssl.SSLError,
                ),
            ):
                time.sleep(sleep_seconds)
                continue

            time.sleep(sleep_seconds)
    raise RuntimeError(f"Could not fetch market data: {last_error}") from last_error


def fetch_json(
    url: str,
    params: dict[str, Any],
    retries: int | None = None,
    timeout: float | None = None,
) -> dict[str, Any]:
    return json.loads(fetch_text(url, params, retries=retries, timeout=timeout))


def parse_history_records(records: list[dict[str, Any]], ticker: str, source_name: str) -> pd.DataFrame:
    if not records:
        raise RuntimeError(f"No valid close prices returned for {ticker} from {source_name}.")
    output = pd.DataFrame.from_records(records)
    output["ds"] = pd.to_datetime(output["ds"]).dt.strftime("%Y-%m-%d")
    output["values"] = output["values"].astype(float)
    return output.dropna().sort_values("ds").reset_index(drop=True)


def load_history_from_eastmoney(
    ticker: str,
    period: str,
    retries: int | None = None,
    timeout: float | None = None,
) -> pd.DataFrame:
    payload = fetch_json(
        EASTMONEY_HISTORY_URL,
        {
            "secid": eastmoney_secid(ticker),
            "fields1": "f1,f2,f3,f4,f5,f6",
            "fields2": "f51,f52,f53,f54,f55,f56,f57,f58,f59,f60,f61",
            "klt": "101",
            "fqt": "1",
            "beg": period_to_start_date(period).strftime("%Y%m%d"),
            "end": (date.today() + timedelta(days=7)).strftime("%Y%m%d"),
            "smplmt": "10000",
            "lmt": "10000",
        },
        retries=retries,
        timeout=timeout,
    )
    rows = payload.get("data", {}).get("klines", [])
    if not rows:
        raise RuntimeError(f"No price history returned for {ticker} from eastmoney.")

    records: list[dict[str, Any]] = []
    for row in rows:
        parts = str(row).split(",")
        if len(parts) < 3:
            continue
        try:
            records.append({"ds": parts[0], "values": float(parts[2])})
        except ValueError:
            continue
    return parse_history_records(records, ticker, "eastmoney")


def load_history_from_tencent(
    ticker: str,
    period: str,
    retries: int | None = None,
    timeout: float | None = None,
) -> pd.DataFrame:
    symbol = tencent_symbol(ticker)
    payload = fetch_json(
        TENCENT_HISTORY_URL,
        {
            "param": ",".join(
                [
                    symbol,
                    "day",
                    period_to_start_date(period).strftime("%Y-%m-%d"),
                    (date.today() + timedelta(days=7)).strftime("%Y-%m-%d"),
                    "1000",
                    "qfq",
                ]
            ),
        },
        retries=retries,
        timeout=timeout,
    )
    symbol_payload = payload.get("data", {}).get(symbol, {})
    rows = symbol_payload.get("qfqday") or symbol_payload.get("day") or []
    if not rows:
        raise RuntimeError(f"No price history returned for {ticker} from tencent.")

    records: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 3:
            continue
        try:
            records.append({"ds": str(row[0]), "values": float(row[2])})
        except (TypeError, ValueError):
            continue
    return parse_history_records(records, ticker, "tencent")


def load_history_from_sohu(
    ticker: str,
    period: str,
    retries: int | None = None,
    timeout: float | None = None,
) -> pd.DataFrame:
    payload_text = fetch_text(
        SOHU_HISTORY_URL,
        {
            "code": sohu_symbol(ticker),
            "start": period_to_start_date(period).strftime("%Y%m%d"),
            "end": (date.today() + timedelta(days=7)).strftime("%Y%m%d"),
            "stat": "1",
            "order": "D",
            "period": "d",
            "rt": "jsonp",
        },
        retries=retries,
        timeout=timeout,
    ).strip()
    if payload_text.startswith("callback(") and payload_text.endswith(")"):
        payload_text = payload_text[len("callback(") : -1]
    payload = json.loads(payload_text)
    if not isinstance(payload, list) or not payload:
        raise RuntimeError(f"No price history returned for {ticker} from sohu.")
    rows = payload[0].get("hq", [])
    if not rows:
        raise RuntimeError(f"No price history returned for {ticker} from sohu.")

    records: list[dict[str, Any]] = []
    for row in rows:
        if not isinstance(row, (list, tuple)) or len(row) < 3:
            continue
        try:
            records.append({"ds": str(row[0]), "values": float(row[2])})
        except (TypeError, ValueError):
            continue
    return parse_history_records(records, ticker, "sohu")


def load_history(
    ticker: str,
    period: str,
    retries: int | None = None,
    timeout: float | None = None,
    source: str | None = None,
) -> pd.DataFrame:
    loaders = {
        "eastmoney": load_history_from_eastmoney,
        "sohu": load_history_from_sohu,
        "tencent": load_history_from_tencent,
    }
    errors: list[str] = []
    for source_name in history_source_order(ticker, source):
        loader = loaders[source_name]
        try:
            history = loader(ticker=ticker, period=period, retries=retries, timeout=timeout)
            history.attrs["history_source"] = source_name
            history.attrs["attempted_sources"] = history_source_order(ticker, source)
            history.attrs["source_errors"] = errors[:]
            return history
        except Exception as exc:
            errors.append(f"{source_name}: {exc}")
    joined_errors = " | ".join(errors[:3]) or "no source attempted"
    raise RuntimeError(f"Could not load price history for {ticker}: {joined_errors}")
